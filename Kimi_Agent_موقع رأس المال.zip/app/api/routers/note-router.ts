import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { notes } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const noteRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(notes).orderBy(desc(notes.isPinned), desc(notes.createdAt));
  }),

  create: publicQuery
    .input(z.object({
      title: z.string().min(1),
      content: z.string().min(1),
      isPinned: z.boolean().default(false),
      priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
      createdBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(notes).values(input);
      return { id: Number(result.insertId) };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      title: z.string().optional(),
      content: z.string().optional(),
      isPinned: z.boolean().optional(),
      priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(notes).set(data).where(eq(notes.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(notes).where(eq(notes.id, input.id));
      return { success: true };
    }),
});
