import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { approvalRequests, partners, cashTransactions, logs } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { sql } from "drizzle-orm";

export const approvalRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(approvalRequests)
      .leftJoin(partners, eq(approvalRequests.requesterId, partners.id))
      .orderBy(desc(approvalRequests.createdAt));
  }),

  listPending: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(approvalRequests)
      .leftJoin(partners, eq(approvalRequests.requesterId, partners.id))
      .where(eq(approvalRequests.status, "pending"))
      .orderBy(desc(approvalRequests.createdAt));
  }),

  create: publicQuery
    .input(z.object({
      requesterId: z.number(),
      type: z.enum(["cash_withdrawal", "cash_transfer", "capital_withdrawal"]),
      amount: z.string(),
      note: z.string().optional(),
      targetPartnerId: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(approvalRequests).values(input);

      const [requester] = await db.select().from(partners).where(eq(partners.id, input.requesterId));

      await db.insert(logs).values({
        type: "approval_requested",
        partnerId: input.requesterId,
        amount: input.amount,
        description: `${input.type} request of ${input.amount} from ${requester?.displayName || "Unknown"}`,
        details: input.note || "",
      });

      return { id: Number(result.insertId) };
    }),

  approve: publicQuery
    .input(z.object({
      id: z.number(),
      reviewedBy: z.number(),
      reviewNote: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [request] = await db.select().from(approvalRequests).where(eq(approvalRequests.id, input.id));
      if (!request) throw new Error("Request not found");

      await db.update(approvalRequests)
        .set({ status: "approved", reviewedBy: input.reviewedBy, reviewNote: input.reviewNote, reviewedAt: new Date() })
        .where(eq(approvalRequests.id, input.id));

      if (request.type === "cash_withdrawal") {
        await db.update(partners)
          .set({ totalCash: sql`total_cash - ${request.amount}` })
          .where(eq(partners.id, request.requesterId));

        const [partner] = await db.select().from(partners).where(eq(partners.id, request.requesterId));
        await db.insert(cashTransactions).values({
          partnerId: request.requesterId,
          type: "withdrawal",
          amount: request.amount,
          note: `Approved withdrawal: ${input.reviewNote || ""}`,
        });
        await db.insert(logs).values({
          type: "approval_approved",
          partnerId: request.requesterId,
          amount: request.amount,
          description: `Cash withdrawal of ${request.amount} approved for ${partner?.displayName || "Unknown"}`,
          details: input.reviewNote || "",
          createdBy: input.reviewedBy,
        });
      } else if (request.type === "cash_transfer" && request.targetPartnerId) {
        await db.update(partners)
          .set({ totalCash: sql`total_cash - ${request.amount}` })
          .where(eq(partners.id, request.requesterId));
        await db.update(partners)
          .set({ totalCash: sql`total_cash + ${request.amount}` })
          .where(eq(partners.id, request.targetPartnerId));

        const [fromPartner] = await db.select().from(partners).where(eq(partners.id, request.requesterId));
        const [toPartner] = await db.select().from(partners).where(eq(partners.id, request.targetPartnerId));
        await db.insert(cashTransactions).values({
          partnerId: request.requesterId,
          type: "transfer",
          amount: request.amount,
          transferToPartnerId: request.targetPartnerId,
          note: `Approved transfer: ${input.reviewNote || ""}`,
        });
        await db.insert(logs).values({
          type: "approval_approved",
          partnerId: request.requesterId,
          targetPartnerId: request.targetPartnerId,
          amount: request.amount,
          description: `Cash transfer of ${request.amount} approved: ${fromPartner?.displayName || "Unknown"} -> ${toPartner?.displayName || "Unknown"}`,
          details: input.reviewNote || "",
          createdBy: input.reviewedBy,
        });
      }

      return { success: true };
    }),

  reject: publicQuery
    .input(z.object({
      id: z.number(),
      reviewedBy: z.number(),
      reviewNote: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [request] = await db.select().from(approvalRequests).where(eq(approvalRequests.id, input.id));

      await db.update(approvalRequests)
        .set({ status: "rejected", reviewedBy: input.reviewedBy, reviewNote: input.reviewNote, reviewedAt: new Date() })
        .where(eq(approvalRequests.id, input.id));

      if (request) {
        const [partner] = await db.select().from(partners).where(eq(partners.id, request.requesterId));
        await db.insert(logs).values({
          type: "approval_rejected",
          partnerId: request.requesterId,
          amount: request.amount,
          description: `${request.type} request of ${request.amount} rejected for ${partner?.displayName || "Unknown"}`,
          details: input.reviewNote || "",
          createdBy: input.reviewedBy,
        });
      }

      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(approvalRequests).where(eq(approvalRequests.id, input.id));
      return { success: true };
    }),
});
