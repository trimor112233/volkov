import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { proofs, partners } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const proofRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(proofs)
      .leftJoin(partners, eq(proofs.partnerId, partners.id))
      .orderBy(desc(proofs.createdAt));
  }),

  create: publicQuery
    .input(z.object({
      title: z.string().min(1),
      description: z.string().optional(),
      type: z.enum(["sale", "purchase", "transfer", "contract", "other"]),
      imageUrl: z.string().optional(),
      partnerId: z.number().optional(),
      createdBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(proofs).values(input);
      return { id: Number(result.insertId) };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(proofs).where(eq(proofs.id, input.id));
      return { success: true };
    }),
});
