import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { companyInfo, logs } from "@db/schema";
import { eq } from "drizzle-orm";

export const companyRouter = createRouter({
  get: publicQuery.query(async () => {
    const db = getDb();
    const [info] = await db.select().from(companyInfo);
    return info || null;
  }),

  update: publicQuery
    .input(z.object({
      companyName: z.string().optional(),
      description: z.string().optional(),
      logo: z.string().optional(),
      foundedDate: z.string().optional(),
      location: z.string().optional(),
      discordLink: z.string().optional(),
      primaryColor: z.string().optional(),
      secondaryColor: z.string().optional(),
      accentColor: z.string().optional(),
      updatedBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.select().from(companyInfo);
      if (existing.length === 0) {
        await db.insert(companyInfo).values(input);
      } else {
        await db.update(companyInfo).set(input).where(eq(companyInfo.id, existing[0].id));
      }

      await db.insert(logs).values({
        type: "company_updated",
        description: "Company information updated",
        createdBy: input.updatedBy,
      });

      return { success: true };
    }),
});
