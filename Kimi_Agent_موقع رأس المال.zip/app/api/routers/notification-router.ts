import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { notifications } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const notificationRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(notifications).orderBy(desc(notifications.createdAt));
  }),

  listByPartner: publicQuery
    .input(z.object({ partnerId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(notifications)
        .where(eq(notifications.partnerId, input.partnerId))
        .orderBy(desc(notifications.createdAt));
    }),

  create: publicQuery
    .input(z.object({
      partnerId: z.number().optional(),
      title: z.string().min(1),
      message: z.string().min(1),
      type: z.enum(["info", "success", "warning", "error"]).default("info"),
      relatedEntityType: z.string().optional(),
      relatedEntityId: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(notifications).values(input);
      return { id: Number(result.insertId) };
    }),

  markRead: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, input.id));
      return { success: true };
    }),

  markAllRead: publicQuery
    .input(z.object({ partnerId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(notifications).set({ isRead: true })
        .where(eq(notifications.partnerId, input.partnerId));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(notifications).where(eq(notifications.id, input.id));
      return { success: true };
    }),

  getUnreadCount: publicQuery
    .input(z.object({ partnerId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const items = await db.select().from(notifications)
        .where(eq(notifications.partnerId, input.partnerId));
      return items.filter(n => !n.isRead).length;
    }),
});
