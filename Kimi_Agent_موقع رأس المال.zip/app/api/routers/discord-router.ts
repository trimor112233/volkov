import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { discordSettings } from "@db/schema";
import { eq } from "drizzle-orm";

export const discordRouter = createRouter({
  get: publicQuery.query(async () => {
    const db = getDb();
    const [settings] = await db.select().from(discordSettings);
    return settings || { id: 1, webhookUrl: "", isEnabled: false, logChannelName: "volkov-logs" };
  }),

  update: publicQuery
    .input(z.object({
      webhookUrl: z.string().optional(),
      isEnabled: z.boolean().optional(),
      logChannelName: z.string().optional(),
      updatedBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.select().from(discordSettings);
      if (existing.length === 0) {
        await db.insert(discordSettings).values(input);
      } else {
        await db.update(discordSettings).set(input).where(eq(discordSettings.id, existing[0].id));
      }
      return { success: true };
    }),

  sendWebhook: publicQuery
    .input(z.object({
      webhookUrl: z.string(),
      embed: z.object({
        title: z.string(),
        description: z.string(),
        color: z.number().optional(),
        fields: z.array(z.object({
          name: z.string(),
          value: z.string(),
          inline: z.boolean().optional(),
        })).optional(),
        image: z.object({ url: z.string() }).optional(),
        footer: z.object({ text: z.string() }).optional(),
        timestamp: z.string().optional(),
      }),
    }))
    .mutation(async ({ input }) => {
      try {
        const response = await fetch(input.webhookUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            embeds: [input.embed],
          }),
        });
        return { success: response.ok };
      } catch (error) {
        return { success: false, error: String(error) };
      }
    }),
});
