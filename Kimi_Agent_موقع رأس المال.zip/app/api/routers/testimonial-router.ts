import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { testimonials } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const testimonialRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(testimonials).orderBy(desc(testimonials.createdAt));
  }),

  create: publicQuery
    .input(z.object({
      name: z.string().min(1),
      discordUsername: z.string().optional(),
      content: z.string().min(1),
      rating: z.number().min(1).max(5).default(5),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(testimonials).values(input);
      return { id: Number(result.insertId) };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(testimonials).where(eq(testimonials.id, input.id));
      return { success: true };
    }),
});
