import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { permissionRoles } from "@db/schema";
import { eq, asc } from "drizzle-orm";

export const permissionRoleRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(permissionRoles).orderBy(asc(permissionRoles.id));
  }),

  create: publicQuery
    .input(z.object({
      name: z.string().min(1),
      displayName: z.string().min(1),
      description: z.string().optional(),
      canViewLogs: z.boolean().default(false),
      canAddCapital: z.boolean().default(false),
      canWithdrawCapital: z.boolean().default(false),
      canAddCash: z.boolean().default(false),
      canWithdrawCash: z.boolean().default(false),
      canTransferCash: z.boolean().default(false),
      canManagePartners: z.boolean().default(false),
      canManageRoles: z.boolean().default(false),
      canManageCompany: z.boolean().default(false),
      canManageAssets: z.boolean().default(false),
      canApproveRequests: z.boolean().default(false),
      canBackup: z.boolean().default(false),
      canEditOwnCashOnly: z.boolean().default(false),
      canViewOwnDataOnly: z.boolean().default(false),
      canManageNotes: z.boolean().default(false),
      canManageProofs: z.boolean().default(false),
      canManageTestimonials: z.boolean().default(false),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(permissionRoles).values(input);
      return { id: Number(result.insertId) };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      displayName: z.string().optional(),
      description: z.string().optional(),
      canViewLogs: z.boolean().optional(),
      canAddCapital: z.boolean().optional(),
      canWithdrawCapital: z.boolean().optional(),
      canAddCash: z.boolean().optional(),
      canWithdrawCash: z.boolean().optional(),
      canTransferCash: z.boolean().optional(),
      canManagePartners: z.boolean().optional(),
      canManageRoles: z.boolean().optional(),
      canManageCompany: z.boolean().optional(),
      canManageAssets: z.boolean().optional(),
      canApproveRequests: z.boolean().optional(),
      canBackup: z.boolean().optional(),
      canEditOwnCashOnly: z.boolean().optional(),
      canViewOwnDataOnly: z.boolean().optional(),
      canManageNotes: z.boolean().optional(),
      canManageProofs: z.boolean().optional(),
      canManageTestimonials: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(permissionRoles).set(data).where(eq(permissionRoles.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(permissionRoles).where(eq(permissionRoles.id, input.id));
      return { success: true };
    }),
});
