import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { cashTransactions, partners, logs } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { sql } from "drizzle-orm";

export const cashRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(cashTransactions)
      .leftJoin(partners, eq(cashTransactions.partnerId, partners.id))
      .orderBy(desc(cashTransactions.createdAt));
  }),

  listByPartner: publicQuery
    .input(z.object({ partnerId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(cashTransactions)
        .leftJoin(partners, eq(cashTransactions.partnerId, partners.id))
        .where(eq(cashTransactions.partnerId, input.partnerId))
        .orderBy(desc(cashTransactions.createdAt));
    }),

  deposit: publicQuery
    .input(z.object({
      partnerId: z.number(),
      amount: z.string(),
      note: z.string().optional(),
      receiptImage: z.string().optional(),
      createdBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { partnerId, amount, ...rest } = input;

      const [txn] = await db.insert(cashTransactions).values({
        partnerId,
        type: "deposit",
        amount,
        ...rest,
      });

      await db.update(partners)
        .set({ totalCash: sql`total_cash + ${amount}` })
        .where(eq(partners.id, partnerId));

      const [partner] = await db.select().from(partners).where(eq(partners.id, partnerId));

      await db.insert(logs).values({
        type: "cash_deposit",
        partnerId,
        amount,
        description: `Cash deposit of ${amount} for ${partner?.displayName || "Unknown"}`,
        details: rest.note || "",
        receiptImage: rest.receiptImage,
        createdBy: rest.createdBy,
      });

      return { id: Number(txn.insertId) };
    }),

  withdraw: publicQuery
    .input(z.object({
      partnerId: z.number(),
      amount: z.string(),
      note: z.string().optional(),
      receiptImage: z.string().optional(),
      createdBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { partnerId, amount, ...rest } = input;

      const [txn] = await db.insert(cashTransactions).values({
        partnerId,
        type: "withdrawal",
        amount,
        ...rest,
      });

      await db.update(partners)
        .set({ totalCash: sql`total_cash - ${amount}` })
        .where(eq(partners.id, partnerId));

      const [partner] = await db.select().from(partners).where(eq(partners.id, partnerId));

      await db.insert(logs).values({
        type: "cash_withdrawal",
        partnerId,
        amount,
        description: `Cash withdrawal of ${amount} for ${partner?.displayName || "Unknown"}`,
        details: rest.note || "",
        receiptImage: rest.receiptImage,
        createdBy: rest.createdBy,
      });

      return { id: Number(txn.insertId) };
    }),

  transfer: publicQuery
    .input(z.object({
      partnerId: z.number(),
      transferToPartnerId: z.number(),
      amount: z.string(),
      note: z.string().optional(),
      receiptImage: z.string().optional(),
      createdBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { partnerId, transferToPartnerId, amount, ...rest } = input;

      const [fromPartner] = await db.select().from(partners).where(eq(partners.id, partnerId));
      const [toPartner] = await db.select().from(partners).where(eq(partners.id, transferToPartnerId));

      const [txn] = await db.insert(cashTransactions).values({
        partnerId,
        type: "transfer",
        amount,
        transferToPartnerId,
        ...rest,
      });

      await db.update(partners)
        .set({ totalCash: sql`total_cash - ${amount}` })
        .where(eq(partners.id, partnerId));

      await db.update(partners)
        .set({ totalCash: sql`total_cash + ${amount}` })
        .where(eq(partners.id, transferToPartnerId));

      await db.insert(logs).values({
        type: "cash_transfer",
        partnerId,
        targetPartnerId: transferToPartnerId,
        amount,
        description: `Cash transfer of ${amount} from ${fromPartner?.displayName || "Unknown"} to ${toPartner?.displayName || "Unknown"}`,
        details: rest.note || "",
        receiptImage: rest.receiptImage,
        createdBy: rest.createdBy,
      });

      return { id: Number(txn.insertId) };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [txn] = await db.select().from(cashTransactions).where(eq(cashTransactions.id, input.id));
      if (txn) {
        if (txn.type === "transfer" && txn.transferToPartnerId) {
          await db.update(partners)
            .set({ totalCash: sql`total_cash + ${txn.amount}` })
            .where(eq(partners.id, txn.partnerId));
          await db.update(partners)
            .set({ totalCash: sql`total_cash - ${txn.amount}` })
            .where(eq(partners.id, txn.transferToPartnerId));
        } else {
          const multiplier = txn.type === "deposit" ? -1 : 1;
          await db.update(partners)
            .set({ totalCash: sql`total_cash + (${multiplier} * ${txn.amount})` })
            .where(eq(partners.id, txn.partnerId));
        }
      }
      await db.delete(cashTransactions).where(eq(cashTransactions.id, input.id));
      return { success: true };
    }),
});
