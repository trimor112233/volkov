import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { companyRoles } from "@db/schema";
import { eq, asc } from "drizzle-orm";

export const companyRoleRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(companyRoles).orderBy(asc(companyRoles.rank));
  }),

  create: publicQuery
    .input(z.object({
      name: z.string().min(1),
      displayName: z.string().min(1),
      rank: z.number().default(0),
      color: z.string().default("#e94560"),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(companyRoles).values(input);
      return { id: Number(result.insertId) };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      displayName: z.string().optional(),
      rank: z.number().optional(),
      color: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(companyRoles).set(data).where(eq(companyRoles.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(companyRoles).where(eq(companyRoles.id, input.id));
      return { success: true };
    }),
});
