import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { capitalTransactions, partners, logs } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const capitalRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(capitalTransactions)
      .leftJoin(partners, eq(capitalTransactions.partnerId, partners.id))
      .orderBy(desc(capitalTransactions.createdAt));
  }),

  listByPartner: publicQuery
    .input(z.object({ partnerId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(capitalTransactions)
        .leftJoin(partners, eq(capitalTransactions.partnerId, partners.id))
        .where(eq(capitalTransactions.partnerId, input.partnerId))
        .orderBy(desc(capitalTransactions.createdAt));
    }),

  deposit: publicQuery
    .input(z.object({
      partnerId: z.number(),
      amount: z.string(),
      note: z.string().optional(),
      receiptImage: z.string().optional(),
      createdBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { partnerId, amount, ...rest } = input;

      const [txn] = await db.insert(capitalTransactions).values({
        partnerId,
        type: "deposit",
        amount,
        ...rest,
      });

      await db.update(partners)
        .set({ totalCapital: sql`total_capital + ${amount}` })
        .where(eq(partners.id, partnerId));

      const [partner] = await db.select().from(partners).where(eq(partners.id, partnerId));

      await db.insert(logs).values({
        type: "capital_deposit",
        partnerId,
        amount,
        description: `Capital deposit of ${amount} for ${partner?.displayName || "Unknown"}`,
        details: rest.note || "",
        receiptImage: rest.receiptImage,
        createdBy: rest.createdBy,
      });

      return { id: Number(txn.insertId) };
    }),

  withdraw: publicQuery
    .input(z.object({
      partnerId: z.number(),
      amount: z.string(),
      note: z.string().optional(),
      receiptImage: z.string().optional(),
      createdBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { partnerId, amount, ...rest } = input;

      const [txn] = await db.insert(capitalTransactions).values({
        partnerId,
        type: "withdrawal",
        amount,
        ...rest,
      });

      await db.update(partners)
        .set({ totalCapital: sql`total_capital - ${amount}` })
        .where(eq(partners.id, partnerId));

      const [partner] = await db.select().from(partners).where(eq(partners.id, partnerId));

      await db.insert(logs).values({
        type: "capital_withdrawal",
        partnerId,
        amount,
        description: `Capital withdrawal of ${amount} for ${partner?.displayName || "Unknown"}`,
        details: rest.note || "",
        receiptImage: rest.receiptImage,
        createdBy: rest.createdBy,
      });

      return { id: Number(txn.insertId) };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [txn] = await db.select().from(capitalTransactions).where(eq(capitalTransactions.id, input.id));
      if (txn) {
        const multiplier = txn.type === "deposit" ? -1 : 1;
        await db.update(partners)
          .set({ totalCapital: sql`total_capital + (${multiplier} * ${txn.amount})` })
          .where(eq(partners.id, txn.partnerId));
      }
      await db.delete(capitalTransactions).where(eq(capitalTransactions.id, input.id));
      return { success: true };
    }),
});
