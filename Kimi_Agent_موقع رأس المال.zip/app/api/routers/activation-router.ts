import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { activationRequests, partners, logs } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const activationRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(activationRequests).orderBy(desc(activationRequests.createdAt));
  }),

  listPending: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(activationRequests)
      .where(eq(activationRequests.status, "pending"))
      .orderBy(desc(activationRequests.createdAt));
  }),

  create: publicQuery
    .input(z.object({
      displayName: z.string().min(1),
      discordUsername: z.string().min(1),
      discordId: z.string().optional(),
      discordAvatar: z.string().optional(),
      discordProfileUrl: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(activationRequests).values({
        ...input,
        status: "pending",
      });
      return { id: Number(result.insertId) };
    }),

  approve: publicQuery
    .input(z.object({
      id: z.number(),
      reviewedBy: z.number(),
      reviewNote: z.string().optional(),
      companyRoleId: z.number().optional(),
      permissionRoleId: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, reviewedBy, reviewNote, companyRoleId, permissionRoleId } = input;

      const [request] = await db.select().from(activationRequests).where(eq(activationRequests.id, id));
      if (!request) throw new Error("Request not found");

      await db.update(activationRequests)
        .set({ status: "approved", reviewedBy, reviewNote, reviewedAt: new Date() })
        .where(eq(activationRequests.id, id));

      const [partnerResult] = await db.insert(partners).values({
        displayName: request.displayName,
        discordUsername: request.discordUsername,
        discordId: request.discordId,
        discordAvatar: request.discordAvatar,
        discordProfileUrl: request.discordProfileUrl,
        companyRoleId: companyRoleId || undefined,
        permissionRoleId: permissionRoleId || undefined,
        totalCapital: "0",
        totalCash: "0",
        isActive: true,
        isPending: false,
        activationRequestId: id,
      });

      await db.insert(logs).values({
        type: "partner_added",
        description: `Partner "${request.displayName}" activated and added`,
        details: reviewNote || "Activation approved",
        createdBy: reviewedBy,
      });

      return { success: true, partnerId: Number(partnerResult.insertId) };
    }),

  reject: publicQuery
    .input(z.object({
      id: z.number(),
      reviewedBy: z.number(),
      reviewNote: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(activationRequests)
        .set({ status: "rejected", reviewedBy: input.reviewedBy, reviewNote: input.reviewNote, reviewedAt: new Date() })
        .where(eq(activationRequests.id, input.id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(activationRequests).where(eq(activationRequests.id, input.id));
      return { success: true };
    }),
});
