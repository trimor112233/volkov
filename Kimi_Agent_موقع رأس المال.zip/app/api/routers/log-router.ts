import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { logs, partners } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const logRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(logs)
      .leftJoin(partners, eq(logs.partnerId, partners.id))
      .orderBy(desc(logs.createdAt));
  }),

  listRecent: publicQuery
    .input(z.object({ limit: z.number().default(50) }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(logs)
        .leftJoin(partners, eq(logs.partnerId, partners.id))
        .orderBy(desc(logs.createdAt))
        .limit(input?.limit || 50);
    }),

  listByPartner: publicQuery
    .input(z.object({ partnerId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(logs)
        .leftJoin(partners, eq(logs.partnerId, partners.id))
        .where(eq(logs.partnerId, input.partnerId))
        .orderBy(desc(logs.createdAt));
    }),

  create: publicQuery
    .input(z.object({
      type: z.enum([
        "capital_deposit", "capital_withdrawal", "cash_deposit", "cash_withdrawal",
        "cash_transfer", "asset_added", "asset_transferred", "partner_added",
        "partner_updated", "role_changed", "company_updated", "approval_requested",
        "approval_approved", "approval_rejected", "login", "logout",
        "note_added", "proof_added", "testimonial_added",
      ]),
      partnerId: z.number().optional(),
      targetPartnerId: z.number().optional(),
      amount: z.string().optional(),
      description: z.string(),
      details: z.string().optional(),
      receiptImage: z.string().optional(),
      createdBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(logs).values(input);
      return { id: Number(result.insertId) };
    }),

  getStats: publicQuery.query(async () => {
    const db = getDb();
    const allLogs = await db.select().from(logs);
    const capitalDeposits = allLogs.filter(l => l.type === "capital_deposit").reduce((s, l) => s + Number(l.amount || 0), 0);
    const capitalWithdrawals = allLogs.filter(l => l.type === "capital_withdrawal").reduce((s, l) => s + Number(l.amount || 0), 0);
    const cashDeposits = allLogs.filter(l => l.type === "cash_deposit").reduce((s, l) => s + Number(l.amount || 0), 0);
    const cashWithdrawals = allLogs.filter(l => l.type === "cash_withdrawal").reduce((s, l) => s + Number(l.amount || 0), 0);
    const cashTransfers = allLogs.filter(l => l.type === "cash_transfer").reduce((s, l) => s + Number(l.amount || 0), 0);
    return { capitalDeposits, capitalWithdrawals, cashDeposits, cashWithdrawals, cashTransfers, totalLogs: allLogs.length };
  }),
});
