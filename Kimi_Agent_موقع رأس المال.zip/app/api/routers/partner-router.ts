import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { partners, companyRoles, permissionRoles, capitalTransactions, cashTransactions, assets } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const partnerRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const allPartners = await db.select().from(partners)
      .leftJoin(companyRoles, eq(partners.companyRoleId, companyRoles.id))
      .leftJoin(permissionRoles, eq(partners.permissionRoleId, permissionRoles.id))
      .orderBy(desc(partners.createdAt));
    return allPartners;
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [partner] = await db.select().from(partners)
        .leftJoin(companyRoles, eq(partners.companyRoleId, companyRoles.id))
        .leftJoin(permissionRoles, eq(partners.permissionRoleId, permissionRoles.id))
        .where(eq(partners.id, input.id));
      if (!partner) return null;

      const capitalTxns = await db.select().from(capitalTransactions)
        .where(eq(capitalTransactions.partnerId, input.id))
        .orderBy(desc(capitalTransactions.createdAt));

      const cashTxns = await db.select().from(cashTransactions)
        .where(eq(cashTransactions.partnerId, input.id))
        .orderBy(desc(cashTransactions.createdAt));

      const partnerAssets = await db.select().from(assets)
        .where(eq(assets.partnerId, input.id))
        .orderBy(desc(assets.createdAt));

      return { ...partner, capitalTransactions: capitalTxns, cashTransactions: cashTxns, assets: partnerAssets };
    }),

  create: publicQuery
    .input(z.object({
      displayName: z.string().min(1),
      discordUsername: z.string().min(1),
      discordId: z.string().optional(),
      discordAvatar: z.string().optional(),
      discordProfileUrl: z.string().optional(),
      companyRoleId: z.number().optional(),
      permissionRoleId: z.number().optional(),
      totalCapital: z.string().default("0"),
      totalCash: z.string().default("0"),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(partners).values(input);
      return { id: Number(result.insertId) };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      displayName: z.string().optional(),
      discordUsername: z.string().optional(),
      discordId: z.string().optional(),
      discordAvatar: z.string().optional(),
      discordProfileUrl: z.string().optional(),
      companyRoleId: z.number().optional(),
      permissionRoleId: z.number().optional(),
      totalCapital: z.string().optional(),
      totalCash: z.string().optional(),
      isActive: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(partners).set(data).where(eq(partners.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(partners).where(eq(partners.id, input.id));
      return { success: true };
    }),

  getStats: publicQuery.query(async () => {
    const db = getDb();
    const allPartners = await db.select().from(partners);
    const totalCapital = allPartners.reduce((sum, p) => sum + Number(p.totalCapital), 0);
    const totalCash = allPartners.reduce((sum, p) => sum + Number(p.totalCash), 0);
    const totalPartners = allPartners.length;
    const activePartners = allPartners.filter(p => p.isActive).length;
    return { totalCapital, totalCash, totalPartners, activePartners };
  }),
});
