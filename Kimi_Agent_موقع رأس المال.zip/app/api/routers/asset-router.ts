import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { assets, assetTransfers, partners, logs } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const assetRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(assets)
      .leftJoin(partners, eq(assets.partnerId, partners.id))
      .orderBy(desc(assets.createdAt));
  }),

  listByPartner: publicQuery
    .input(z.object({ partnerId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(assets)
        .where(eq(assets.partnerId, input.partnerId))
        .orderBy(desc(assets.createdAt));
    }),

  create: publicQuery
    .input(z.object({
      partnerId: z.number(),
      assetName: z.string().min(1),
      assetType: z.enum(["vehicles", "real_estate", "equipment", "other"]),
      assetIdCode: z.string().min(1),
      description: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(assets).values(input);

      const [partner] = await db.select().from(partners).where(eq(partners.id, input.partnerId));
      await db.insert(logs).values({
        type: "asset_added",
        partnerId: input.partnerId,
        description: `Asset "${input.assetName}" (${input.assetType}) added for ${partner?.displayName || "Unknown"}`,
        details: input.description || "",
      });

      return { id: Number(result.insertId) };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      assetName: z.string().optional(),
      assetType: z.enum(["vehicles", "real_estate", "equipment", "other"]).optional(),
      assetIdCode: z.string().optional(),
      description: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(assets).set(data).where(eq(assets.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(assets).where(eq(assets.id, input.id));
      return { success: true };
    }),

  transfer: publicQuery
    .input(z.object({
      assetId: z.number(),
      fromPartnerId: z.number(),
      toPartnerId: z.number(),
      toPartnerName: z.string(),
      toPartnerDiscordId: z.string().optional(),
      note: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { assetId, fromPartnerId, toPartnerId, ...rest } = input;

      await db.update(assets)
        .set({ partnerId: toPartnerId })
        .where(eq(assets.id, assetId));

      const [asset] = await db.select().from(assets).where(eq(assets.id, assetId));
      const [fromPartner] = await db.select().from(partners).where(eq(partners.id, fromPartnerId));
      const [toPartner] = await db.select().from(partners).where(eq(partners.id, toPartnerId));

      await db.insert(assetTransfers).values({
        assetId,
        fromPartnerId,
        toPartnerId,
        ...rest,
      });

      await db.insert(logs).values({
        type: "asset_transferred",
        partnerId: fromPartnerId,
        targetPartnerId: toPartnerId,
        description: `Asset "${asset?.assetName || "Unknown"}" transferred from ${fromPartner?.displayName || "Unknown"} to ${toPartner?.displayName || rest.toPartnerName}`,
        details: rest.note || "",
      });

      return { success: true };
    }),

  getTransfers: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(assetTransfers)
      .leftJoin(assets, eq(assetTransfers.assetId, assets.id))
      .leftJoin(partners, eq(assetTransfers.fromPartnerId, partners.id))
      .orderBy(desc(assetTransfers.createdAt));
  }),
});
