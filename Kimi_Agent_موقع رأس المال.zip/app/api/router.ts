import { authRouter } from "./auth-router";
import { createRouter, publicQuery } from "./middleware";
import { partnerRouter } from "./routers/partner-router";
import { capitalRouter } from "./routers/capital-router";
import { cashRouter } from "./routers/cash-router";
import { assetRouter } from "./routers/asset-router";
import { logRouter } from "./routers/log-router";
import { testimonialRouter } from "./routers/testimonial-router";
import { proofRouter } from "./routers/proof-router";
import { noteRouter } from "./routers/note-router";
import { companyRouter } from "./routers/company-router";
import { activationRouter } from "./routers/activation-router";
import { approvalRouter } from "./routers/approval-router";
import { discordRouter } from "./routers/discord-router";
import { companyRoleRouter } from "./routers/company-role-router";
import { permissionRoleRouter } from "./routers/permission-role-router";
import { notificationRouter } from "./routers/notification-router";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  partner: partnerRouter,
  capital: capitalRouter,
  cash: cashRouter,
  asset: assetRouter,
  log: logRouter,
  testimonial: testimonialRouter,
  proof: proofRouter,
  note: noteRouter,
  company: companyRouter,
  activation: activationRouter,
  approval: approvalRouter,
  discord: discordRouter,
  companyRole: companyRoleRouter,
  permissionRole: permissionRoleRouter,
  notification: notificationRouter,
});

export type AppRouter = typeof appRouter;
