import { Routes, Route } from 'react-router'
import { ThemeProvider } from './providers/theme'
import Layout from './components/Layout'
import Home from './pages/Home'
import Partners from './pages/Partners'
import PartnerDetail from './pages/PartnerDetail'
import Capital from './pages/Capital'
import Cash from './pages/Cash'
import Logs from './pages/Logs'
import Assets from './pages/Assets'
import Testimonials from './pages/Testimonials'
import Proofs from './pages/Proofs'
import NotesPage from './pages/NotesPage'
import CompanyInfoPage from './pages/CompanyInfoPage'
import ActivationRequests from './pages/ActivationRequests'
import ApprovalRequests from './pages/ApprovalRequests'
import Settings from './pages/Settings'
import Activate from './pages/Activate'
import Login from './pages/Login'
import NotFound from './pages/NotFound'

export default function App() {
  return (
    <ThemeProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/activate" element={<Activate />} />
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/partners" element={<Partners />} />
          <Route path="/partners/:id" element={<PartnerDetail />} />
          <Route path="/capital" element={<Capital />} />
          <Route path="/cash" element={<Cash />} />
          <Route path="/logs" element={<Logs />} />
          <Route path="/assets" element={<Assets />} />
          <Route path="/testimonials" element={<Testimonials />} />
          <Route path="/proofs" element={<Proofs />} />
          <Route path="/notes" element={<NotesPage />} />
          <Route path="/company" element={<CompanyInfoPage />} />
          <Route path="/activation-requests" element={<ActivationRequests />} />
          <Route path="/approval-requests" element={<ApprovalRequests />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </ThemeProvider>
  )
}
