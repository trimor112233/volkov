import { useState } from "react";
import { Outlet, useLocation, Link } from "react-router";
import { useTheme } from "@/providers/theme";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Home,
  Users,
  Landmark,
  Banknote,
  ClipboardList,
  Car,
  MessageSquareQuote,
  FileCheck,
  StickyNote,
  Building2,
  UserPlus,
  ClipboardCheck,
  Settings,
  Sun,
  Moon,
  Menu,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Bell,
  X,
} from "lucide-react";

const navItems = [
  { icon: Home, label: "Dashboard", path: "/" },
  { icon: Users, label: "Partners & Balances", path: "/partners" },
  { icon: Landmark, label: "Capital", path: "/capital" },
  { icon: Banknote, label: "Cash", path: "/cash" },
  { icon: ClipboardList, label: "Logs", path: "/logs" },
  { icon: Car, label: "Assets", path: "/assets" },
  { icon: MessageSquareQuote, label: "Testimonials", path: "/testimonials" },
  { icon: FileCheck, label: "Proofs", path: "/proofs" },
  { icon: StickyNote, label: "Notes", path: "/notes" },
  { icon: Building2, label: "Company Info", path: "/company" },
  { icon: UserPlus, label: "Activation Requests", path: "/activation-requests" },
  { icon: ClipboardCheck, label: "Approval Requests", path: "/approval-requests" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

export default function Layout() {
  const { setTheme, resolvedTheme } = useTheme();
  const { user, logout } = useAuth();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showNotifs, setShowNotifs] = useState(false);
  const utils = trpc.useUtils();

  const { data: notifications } = trpc.notification.list.useQuery();
  const unreadCount = notifications?.filter((n) => !n.isRead).length || 0;

  const markRead = trpc.notification.markRead.useMutation({
    onSuccess: () => {
      utils.notification.list.invalidate();
    },
  });

  const currentPage =
    navItems.find((item) => item.path === location.pathname)?.label || "Volkov Company";

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-3 px-4 py-5 border-b border-border">
        <img src="/volkov-logo.png" alt="Volkov" className="h-10 w-10 object-contain" />
        {!collapsed && (
          <div className="flex flex-col">
            <span className="font-bold text-lg leading-tight text-gradient">VOLKOV</span>
            <span className="text-[10px] text-muted-foreground tracking-widest uppercase">
              Company ERP
            </span>
          </div>
        )}
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-1">
        <TooltipProvider delayDuration={collapsed ? 100 : 999999}>
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Tooltip key={item.path}>
                <TooltipTrigger asChild>
                  <Link
                    to={item.path}
                    onClick={() => setMobileOpen(false)}
                    className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200 ${
                      isActive
                        ? "bg-primary/10 text-primary border-l-2 border-primary"
                        : "text-muted-foreground hover:bg-accent hover:text-foreground"
                    }`}
                  >
                    <item.icon className="h-[18px] w-[18px] flex-shrink-0" />
                    {!collapsed && <span>{item.label}</span>}
                  </Link>
                </TooltipTrigger>
                {collapsed && <TooltipContent side="right">{item.label}</TooltipContent>}
              </Tooltip>
            );
          })}
        </TooltipProvider>
      </nav>

      <div className="border-t border-border p-3 space-y-2">
        <div className="flex items-center gap-2 px-2">
          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
            <span className="text-xs font-bold">
              {user?.name?.charAt(0) || "U"}
            </span>
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium truncate">{user?.name || "Guest"}</p>
              <p className="text-[10px] text-muted-foreground truncate">
                {user?.role || "Member"}
              </p>
            </div>
          )}
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start gap-2 text-xs"
          onClick={() => logout()}
        >
          <LogOut className="h-4 w-4" />
          {!collapsed && "Sign Out"}
        </Button>
        {!collapsed && (
          <p className="text-[10px] text-muted-foreground text-center pt-1">
            Developed By: <span className="font-mono text-[var(--volkov-accent)]">_.400</span>
          </p>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:flex flex-col border-r border-border bg-card transition-all duration-300 relative ${
          collapsed ? "w-16" : "w-64"
        }`}
      >
        <SidebarContent />
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute bottom-20 -right-3 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors"
        >
          {collapsed ? <ChevronRight className="h-3 w-3" /> : <ChevronLeft className="h-3 w-3" />}
        </button>
      </aside>

      {/* Mobile Sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetTrigger asChild className="lg:hidden">
          <Button variant="ghost" size="icon" className="fixed top-3 left-3 z-50">
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0">
          <SidebarContent />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-14 border-b border-border bg-card/50 backdrop-blur-sm flex items-center justify-between px-4 lg:px-6 flex-shrink-0">
          <div className="flex items-center gap-3">
            <span className="lg:hidden w-8" />
            <h1 className="text-sm font-semibold text-muted-foreground">
              {currentPage}{" "}
              <span className="text-muted-foreground/50">| Volkov Company</span>
            </h1>
          </div>

          <div className="flex items-center gap-2">
            {/* Notifications */}
            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                className="relative"
                onClick={() => setShowNotifs(!showNotifs)}
              >
                <Bell className="h-[18px] w-[18px]" />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-[var(--volkov-accent)] text-[10px] font-bold text-white flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </Button>
              {showNotifs && (
                <div className="absolute right-0 top-12 w-80 bg-card border border-border rounded-lg shadow-xl z-50 max-h-96 overflow-y-auto">
                  <div className="flex items-center justify-between p-3 border-b border-border">
                    <span className="text-sm font-semibold">Notifications</span>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setShowNotifs(false)}>
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                  {notifications && notifications.length > 0 ? (
                    notifications.slice(0, 10).map((n) => (
                      <div
                        key={n.id}
                        className={`p-3 border-b border-border/50 cursor-pointer hover:bg-accent/50 transition-colors ${
                          !n.isRead ? "bg-primary/5" : ""
                        }`}
                        onClick={() => {
                          if (!n.isRead) markRead.mutate({ id: n.id });
                        }}
                      >
                        <p className="text-xs font-medium">{n.title}</p>
                        <p className="text-[11px] text-muted-foreground line-clamp-2">{n.message}</p>
                      </div>
                    ))
                  ) : (
                    <p className="p-4 text-xs text-muted-foreground text-center">No notifications</p>
                  )}
                </div>
              )}
            </div>

            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
            >
              {resolvedTheme === "dark" ? <Sun className="h-[18px] w-[18px]" /> : <Moon className="h-[18px] w-[18px]" />}
            </Button>

            {/* Logo */}
            <img src="/volkov-logo.png" alt="Volkov" className="h-8 w-8 object-contain" />
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
