import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Building2, Save } from "lucide-react";

export default function CompanyInfoPage() {
  const { data: company, isLoading } = trpc.company.get.useQuery();
  const utils = trpc.useUtils();
  const [isEditing, setIsEditing] = useState(false);
  const [form, setForm] = useState({
    companyName: "",
    description: "",
    foundedDate: "",
    location: "",
    discordLink: "",
  });

  const update = trpc.company.update.useMutation({
    onSuccess: () => { utils.company.get.invalidate(); setIsEditing(false); },
  });

  const startEdit = () => {
    if (company) {
      setForm({
        companyName: company.companyName || "",
        description: company.description || "",
        foundedDate: company.foundedDate || "",
        location: company.location || "",
        discordLink: company.discordLink || "",
      });
    }
    setIsEditing(true);
  };

  if (isLoading) return <div className="text-center py-20 text-muted-foreground">Loading...</div>;

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <Building2 className="h-5 w-5 text-[var(--volkov-accent)]" />
          Company Information
        </h1>
        {!isEditing && <Button size="sm" onClick={startEdit}>Edit Info</Button>}
      </div>

      {!isEditing ? (
        <Card className="border-border/60">
          <CardContent className="p-6 space-y-4">
            <div className="flex justify-center mb-4">
              <img src="/volkov-logo.png" alt="Volkov" className="h-32 w-32 object-contain" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase">Company Name</p>
              <p className="text-lg font-bold">{company?.companyName || "Volkov Company"}</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase">Description</p>
              <p className="text-sm text-muted-foreground leading-relaxed">{company?.description || "No description set."}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-[10px] text-muted-foreground uppercase">Founded</p>
                <p className="text-sm font-medium">{company?.foundedDate || "N/A"}</p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground uppercase">Location</p>
                <p className="text-sm font-medium">{company?.location || "N/A"}</p>
              </div>
            </div>
            {company?.discordLink && (
              <div>
                <p className="text-[10px] text-muted-foreground uppercase">Discord</p>
                <a href={company.discordLink} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-500 hover:underline">{company.discordLink}</a>
              </div>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card className="border-border/60">
          <CardContent className="p-6 space-y-4">
            <div>
              <Label className="text-xs">Company Name</Label>
              <Input value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} />
            </div>
            <div>
              <Label className="text-xs">Description</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={4} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs">Founded Date</Label>
                <Input value={form.foundedDate} onChange={(e) => setForm({ ...form, foundedDate: e.target.value })} placeholder="e.g. 2024" />
              </div>
              <div>
                <Label className="text-xs">Location</Label>
                <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
              </div>
            </div>
            <div>
              <Label className="text-xs">Discord Link</Label>
              <Input value={form.discordLink} onChange={(e) => setForm({ ...form, discordLink: e.target.value })} placeholder="https://discord.gg/..." />
            </div>
            <div className="flex gap-2">
              <Button className="flex-1 gap-1" onClick={() => update.mutate(form)}><Save className="h-4 w-4" /> Save</Button>
              <Button variant="outline" onClick={() => setIsEditing(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
