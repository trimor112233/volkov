import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { FileCheck, Plus } from "lucide-react";

export default function Proofs() {
  const { data: proofs } = trpc.proof.list.useQuery();
  const utils = trpc.useUtils();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", description: "", type: "other" as const, imageUrl: "" });

  const create = trpc.proof.create.useMutation({
    onSuccess: () => { utils.proof.list.invalidate(); setShowForm(false); setForm({ title: "", description: "", type: "other", imageUrl: "" }); },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <FileCheck className="h-5 w-5 text-[var(--volkov-accent)]" />
          Proofs & Evidence
        </h1>
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1"><Plus className="h-4 w-4" /> Add Proof</Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Add Proof/Evidence</DialogTitle></DialogHeader>
            <div className="space-y-3 pt-2">
              <div><Label className="text-xs">Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Sale Receipt #123" /></div>
              <div><Label className="text-xs">Type</Label>
                <Select onValueChange={(v) => setForm({ ...form, type: v as typeof form.type })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sale">Sale</SelectItem>
                    <SelectItem value="purchase">Purchase</SelectItem>
                    <SelectItem value="transfer">Transfer</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label className="text-xs">Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Details..." rows={2} /></div>
              <div><Label className="text-xs">Image URL</Label><Input value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} placeholder="https://..." /></div>
              <Button className="w-full" onClick={() => create.mutate(form)} disabled={!form.title}>Add Proof</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {proofs && proofs.length > 0 ? proofs.map((p) => (
          <Card key={p.proofs.id} className="card-hover border-border/60 overflow-hidden">
            {p.proofs.imageUrl && (
              <div className="h-32 bg-accent/30 flex items-center justify-center">
                <img src={p.proofs.imageUrl} alt={p.proofs.title} className="h-full w-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
              </div>
            )}
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-bold uppercase text-[var(--volkov-accent)]">{p.proofs.type}</span>
              </div>
              <p className="text-sm font-semibold">{p.proofs.title}</p>
              {p.proofs.description && <p className="text-xs text-muted-foreground mt-1">{p.proofs.description}</p>}
              <p className="text-[10px] text-muted-foreground mt-2">{p.proofs.createdAt ? new Date(p.proofs.createdAt).toLocaleDateString("en-US") : ""}</p>
            </CardContent>
          </Card>
        )) : <p className="col-span-full text-center text-muted-foreground py-12">No proofs added yet</p>}
      </div>
    </div>
  );
}
