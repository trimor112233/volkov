import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Star, Plus, MessageSquareQuote } from "lucide-react";

export default function Testimonials() {
  const { data: testimonials } = trpc.testimonial.list.useQuery();
  const utils = trpc.useUtils();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", discordUsername: "", content: "", rating: 5 });

  const create = trpc.testimonial.create.useMutation({
    onSuccess: () => { utils.testimonial.list.invalidate(); setShowForm(false); setForm({ name: "", discordUsername: "", content: "", rating: 5 }); },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <MessageSquareQuote className="h-5 w-5 text-[var(--volkov-accent)]" />
          Reviews & Opinions
        </h1>
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1"><Plus className="h-4 w-4" /> Add Review</Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Write a Review</DialogTitle></DialogHeader>
            <div className="space-y-3 pt-2">
              <div>
                <Label className="text-xs">Your Name</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" />
              </div>
              <div>
                <Label className="text-xs">Discord Username (optional)</Label>
                <Input value={form.discordUsername} onChange={(e) => setForm({ ...form, discordUsername: e.target.value })} placeholder="@username" />
              </div>
              <div>
                <Label className="text-xs">Rating</Label>
                <div className="flex gap-1 mt-1">
                  {[1, 2, 3, 4, 5].map((r) => (
                    <button key={r} onClick={() => setForm({ ...form, rating: r })}>
                      <Star className={`h-6 w-6 ${r <= form.rating ? "fill-amber-400 text-amber-400" : "text-muted"}`} />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <Label className="text-xs">Your Review</Label>
                <Textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} placeholder="Share your experience..." rows={3} />
              </div>
              <Button className="w-full" onClick={() => create.mutate(form)} disabled={!form.name || !form.content}>Submit Review</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {testimonials && testimonials.length > 0 ? testimonials.map((t) => (
          <Card key={t.id} className="card-hover border-border/60">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-sm font-bold">{t.name.charAt(0)}</span>
                </div>
                <div>
                  <p className="text-sm font-semibold">{t.name}</p>
                  {t.discordUsername && <p className="text-[10px] text-muted-foreground font-mono">@{t.discordUsername}</p>}
                </div>
              </div>
              <div className="flex gap-0.5 mb-2">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">{t.content}</p>
              <p className="text-[10px] text-muted-foreground mt-2">{t.createdAt ? new Date(t.createdAt).toLocaleDateString("en-US") : ""}</p>
            </CardContent>
          </Card>
        )) : <p className="col-span-full text-center text-muted-foreground py-12">No reviews yet. Be the first to share your opinion!</p>}
      </div>
    </div>
  );
}
