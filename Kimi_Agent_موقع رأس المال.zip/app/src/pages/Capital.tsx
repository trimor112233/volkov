import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Landmark, Plus, TrendingUp, TrendingDown } from "lucide-react";

function formatMoney(value: number | string) {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0";
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
  return num.toLocaleString("en-US");
}

export default function Capital() {
  const { data: partners } = trpc.partner.list.useQuery();
  const { data: transactions } = trpc.capital.list.useQuery();
  const { data: stats } = trpc.partner.getStats.useQuery();
  const utils = trpc.useUtils();

  const [showForm, setShowForm] = useState(false);
  const [formType, setFormType] = useState<"deposit" | "withdrawal">("deposit");
  const [formData, setFormData] = useState({ partnerId: "", amount: "", note: "" });

  const depositMutation = trpc.capital.deposit.useMutation({
    onSuccess: () => { utils.capital.list.invalidate(); utils.partner.list.invalidate(); utils.partner.getStats.invalidate(); utils.log.list.invalidate(); setShowForm(false); resetForm(); },
  });
  const withdrawMutation = trpc.capital.withdraw.useMutation({
    onSuccess: () => { utils.capital.list.invalidate(); utils.partner.list.invalidate(); utils.partner.getStats.invalidate(); utils.log.list.invalidate(); setShowForm(false); resetForm(); },
  });

  const resetForm = () => setFormData({ partnerId: "", amount: "", note: "" });

  const handleSubmit = () => {
    if (!formData.partnerId || !formData.amount) return;
    const payload = { partnerId: Number(formData.partnerId), amount: formData.amount, note: formData.note };
    if (formType === "deposit") depositMutation.mutate(payload);
    else withdrawMutation.mutate(payload);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <Landmark className="h-5 w-5 text-[var(--volkov-accent)]" />
          Capital Management
        </h1>
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1"><Plus className="h-4 w-4" /> Add Capital</Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Capital Transaction</DialogTitle></DialogHeader>
            <div className="space-y-3 pt-2">
              <div className="flex gap-2">
                <Button variant={formType === "deposit" ? "default" : "outline"} size="sm" onClick={() => setFormType("deposit")} className="flex-1 gap-1">
                  <TrendingUp className="h-4 w-4" /> Deposit
                </Button>
                <Button variant={formType === "withdrawal" ? "default" : "outline"} size="sm" onClick={() => setFormType("withdrawal")} className="flex-1 gap-1">
                  <TrendingDown className="h-4 w-4" /> Withdraw
                </Button>
              </div>
              <div>
                <Label className="text-xs">Partner</Label>
                <Select onValueChange={(v) => setFormData({ ...formData, partnerId: v })}>
                  <SelectTrigger><SelectValue placeholder="Select partner" /></SelectTrigger>
                  <SelectContent>
                    {partners?.map((p) => (
                      <SelectItem key={p.partners.id} value={String(p.partners.id)}>{p.partners.displayName}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Amount</Label>
                <Input type="number" value={formData.amount} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} placeholder="0.00" />
              </div>
              <div>
                <Label className="text-xs">Note (optional)</Label>
                <Textarea value={formData.note} onChange={(e) => setFormData({ ...formData, note: e.target.value })} placeholder="Reason for transaction..." rows={2} />
              </div>
              <Button className="w-full" onClick={handleSubmit} disabled={!formData.partnerId || !formData.amount}>
                {formType === "deposit" ? "Deposit Capital" : "Withdraw Capital"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-border/60 bg-emerald-500/5">
          <CardContent className="p-4">
            <p className="text-[10px] text-muted-foreground uppercase">Total Capital</p>
            <p className="text-2xl font-bold number-format text-emerald-500">{formatMoney(stats?.totalCapital || 0)}</p>
            <p className="text-[10px] text-muted-foreground number-format">{Number(stats?.totalCapital || 0).toLocaleString("en-US")}</p>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="p-4">
            <p className="text-[10px] text-muted-foreground uppercase">Deposits</p>
            <p className="text-2xl font-bold number-format text-emerald-500">
              {formatMoney(transactions?.filter((t) => t.capital_transactions.type === "deposit").reduce((s, t) => s + Number(t.capital_transactions.amount), 0) || 0)}
            </p>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="p-4">
            <p className="text-[10px] text-muted-foreground uppercase">Withdrawals</p>
            <p className="text-2xl font-bold number-format text-red-500">
              {formatMoney(transactions?.filter((t) => t.capital_transactions.type === "withdrawal").reduce((s, t) => s + Number(t.capital_transactions.amount), 0) || 0)}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/60">
        <CardHeader className="pb-2"><CardTitle className="text-sm">Recent Capital Transactions</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-2">
            {transactions && transactions.length > 0 ? transactions.slice(0, 20).map((tx) => (
              <div key={tx.capital_transactions.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-accent/50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${tx.capital_transactions.type === "deposit" ? "bg-emerald-500/10" : "bg-red-500/10"}`}>
                    {tx.capital_transactions.type === "deposit" ? <TrendingUp className="h-4 w-4 text-emerald-500" /> : <TrendingDown className="h-4 w-4 text-red-500" />}
                  </div>
                  <div>
                    <p className="text-xs font-medium">{tx.partners?.displayName || "Unknown"}</p>
                    <p className="text-[10px] text-muted-foreground">{tx.capital_transactions.note || "No note"}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-bold number-format ${tx.capital_transactions.type === "deposit" ? "text-emerald-500" : "text-red-500"}`}>
                    {tx.capital_transactions.type === "deposit" ? "+" : "-"}{formatMoney(tx.capital_transactions.amount)}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{tx.capital_transactions.createdAt ? new Date(tx.capital_transactions.createdAt).toLocaleDateString("en-US") : ""}</p>
                </div>
              </div>
            )) : <p className="text-xs text-muted-foreground text-center py-6">No transactions</p>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
