import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { StickyNote, Plus, Pin, Trash2 } from "lucide-react";

const priorityColors: Record<string, string> = { low: "bg-blue-500/10 text-blue-500", medium: "bg-amber-500/10 text-amber-500", high: "bg-orange-500/10 text-orange-500", urgent: "bg-red-500/10 text-red-500" };

export default function NotesPage() {
  const { data: notes } = trpc.note.list.useQuery();
  const utils = trpc.useUtils();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", content: "", priority: "medium" as const });

  const create = trpc.note.create.useMutation({
    onSuccess: () => { utils.note.list.invalidate(); setShowForm(false); setForm({ title: "", content: "", priority: "medium" }); },
  });
  const togglePin = trpc.note.update.useMutation({ onSuccess: () => utils.note.list.invalidate() });
  const remove = trpc.note.delete.useMutation({ onSuccess: () => utils.note.list.invalidate() });

  const sorted = notes ? [...notes].sort((a, b) => (b.isPinned === a.isPinned ? 0 : b.isPinned ? 1 : -1)) : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <StickyNote className="h-5 w-5 text-[var(--volkov-accent)]" />
          Important Notes
        </h1>
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1"><Plus className="h-4 w-4" /> Add Note</Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Add Important Note</DialogTitle></DialogHeader>
            <div className="space-y-3 pt-2">
              <div><Label className="text-xs">Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Note title" /></div>
              <div><Label className="text-xs">Priority</Label>
                <Select onValueChange={(v) => setForm({ ...form, priority: v as typeof form.priority })} defaultValue="medium">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label className="text-xs">Content</Label><Textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} placeholder="Important details..." rows={3} /></div>
              <Button className="w-full" onClick={() => create.mutate(form)} disabled={!form.title || !form.content}>Add Note</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        {sorted.length > 0 ? sorted.map((n) => (
          <Card key={n.id} className={`border-border/60 ${n.isPinned ? "border-l-2 border-l-[var(--volkov-accent)]" : ""}`}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {n.isPinned && <Pin className="h-3.5 w-3.5 text-[var(--volkov-accent)]" />}
                    <p className="text-sm font-semibold">{n.title}</p>
                    <Badge variant="outline" className={`text-[9px] h-5 ${priorityColors[n.priority]}`}>{n.priority}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{n.content}</p>
                  <p className="text-[10px] text-muted-foreground mt-2">{n.createdAt ? new Date(n.createdAt).toLocaleDateString("en-US") : ""}</p>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => togglePin.mutate({ id: n.id, isPinned: !n.isPinned })}>
                    <Pin className={`h-3.5 w-3.5 ${n.isPinned ? "text-[var(--volkov-accent)]" : "text-muted-foreground"}`} />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => remove.mutate({ id: n.id })}>
                    <Trash2 className="h-3.5 w-3.5 text-red-500" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )) : <p className="text-center text-muted-foreground py-12">No notes yet</p>}
      </div>
    </div>
  );
}
