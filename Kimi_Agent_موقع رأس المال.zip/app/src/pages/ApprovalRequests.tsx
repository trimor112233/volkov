import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { ClipboardCheck, CheckCircle, XCircle, Clock } from "lucide-react";

function formatMoney(value: number | string) {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0";
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
  return num.toLocaleString("en-US");
}

export default function ApprovalRequests() {
  const { data: requests } = trpc.approval.list.useQuery();
  const utils = trpc.useUtils();
  const [reviewNote, setReviewNote] = useState("");
  const [reviewingId, setReviewingId] = useState<number | null>(null);

  const approve = trpc.approval.approve.useMutation({
    onSuccess: () => { utils.approval.list.invalidate(); setReviewingId(null); setReviewNote(""); },
  });
  const reject = trpc.approval.reject.useMutation({
    onSuccess: () => { utils.approval.list.invalidate(); setReviewingId(null); setReviewNote(""); },
  });

  const pending = requests?.filter((r) => r.approval_requests.status === "pending") || [];
  const processed = requests?.filter((r) => r.approval_requests.status !== "pending") || [];

  const typeLabel = (type: string) => {
    if (type === "cash_withdrawal") return "Cash Withdrawal";
    if (type === "cash_transfer") return "Cash Transfer";
    if (type === "capital_withdrawal") return "Capital Withdrawal";
    return type;
  };

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold flex items-center gap-2">
        <ClipboardCheck className="h-5 w-5 text-[var(--volkov-accent)]" />
        Approval Requests
      </h1>

      <Card className="border-border/60">
        <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Clock className="h-4 w-4 text-amber-500" /> Pending ({pending.length})</CardTitle></CardHeader>
        <CardContent>
          {pending.length > 0 ? pending.map((r) => (
            <div key={r.approval_requests.id} className="p-4 rounded-lg bg-amber-500/5 border border-amber-500/20 mb-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{r.partners?.displayName || "Unknown"}</span>
                  <Badge variant="outline" className="text-[9px]">{typeLabel(r.approval_requests.type)}</Badge>
                </div>
                <span className="text-lg font-bold text-[var(--volkov-accent)] number-format">{formatMoney(r.approval_requests.amount)}</span>
              </div>
              {r.approval_requests.note && <p className="text-xs text-muted-foreground mb-2">{r.approval_requests.note}</p>}
              <p className="text-[10px] text-muted-foreground mb-3">{r.approval_requests.createdAt ? new Date(r.approval_requests.createdAt).toLocaleString("en-US") : ""}</p>

              {reviewingId === r.approval_requests.id ? (
                <div className="space-y-2">
                  <Textarea value={reviewNote} onChange={(e) => setReviewNote(e.target.value)} placeholder="Review note (optional)..." rows={2} />
                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1 gap-1 bg-emerald-500 hover:bg-emerald-600" onClick={() => approve.mutate({ id: r.approval_requests.id, reviewedBy: 1, reviewNote })}>
                      <CheckCircle className="h-3.5 w-3.5" /> Approve
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 gap-1 text-red-500" onClick={() => reject.mutate({ id: r.approval_requests.id, reviewedBy: 1, reviewNote })}>
                      <XCircle className="h-3.5 w-3.5" /> Reject
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Button size="sm" className="flex-1 gap-1" onClick={() => setReviewingId(r.approval_requests.id)}>Review Request</Button>
                </div>
              )}
            </div>
          )) : <p className="text-xs text-muted-foreground text-center py-6">No pending approval requests</p>}
        </CardContent>
      </Card>

      {processed.length > 0 && (
        <Card className="border-border/60">
          <CardHeader className="pb-2"><CardTitle className="text-sm">Processed</CardTitle></CardHeader>
          <CardContent>
            {processed.map((r) => (
              <div key={r.approval_requests.id} className="flex items-center justify-between p-3 rounded-lg bg-accent/20 mb-2">
                <div className="flex items-center gap-3">
                  <div>
                    <p className="text-xs font-medium">{r.partners?.displayName || "Unknown"}</p>
                    <p className="text-[10px] text-muted-foreground">{typeLabel(r.approval_requests.type)} - {formatMoney(r.approval_requests.amount)}</p>
                  </div>
                </div>
                <Badge variant={r.approval_requests.status === "approved" ? "default" : "secondary"}>
                  {r.approval_requests.status}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
