import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "react-router";
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  Users,
  Activity,
  ArrowRight,
  Crown,
  Star,
  MessageSquareQuote,
  ShieldCheck,
} from "lucide-react";

function formatMoney(value: number | string) {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0";
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
  return num.toLocaleString("en-US");
}

function formatMoneyFull(value: number | string) {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0";
  return num.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

export default function Home() {
  const { data: stats, isLoading: statsLoading } = trpc.partner.getStats.useQuery();
  const { data: partnersData } = trpc.partner.list.useQuery();
  const { data: recentLogs } = trpc.log.listRecent.useQuery({ limit: 10 });
  const { data: testimonials } = trpc.testimonial.list.useQuery();
  const { data: companyData } = trpc.company.get.useQuery();
  const { data: pendingActivations } = trpc.activation.listPending.useQuery();
  const { data: pendingApprovals } = trpc.approval.listPending.useQuery();

  const activePartners = partnersData
    ?.filter((p) => p.partners.isActive)
    .sort((a, b) => Number(b.partners.totalCapital) - Number(a.partners.totalCapital));

  const companyInfo = companyData;

  return (
    <div className="space-y-6">
      {/* Company Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[var(--volkov-primary)] via-[var(--volkov-secondary)] to-[var(--volkov-primary)] p-6 lg:p-8 border border-border/50">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: "radial-gradient(circle at 2px 2px, rgba(233,69,96,0.3) 1px, transparent 0)",
          backgroundSize: "24px 24px",
        }} />
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center gap-6">
          <img src="/volkov-logo.png" alt="Volkov" className="h-20 w-20 lg:h-24 lg:w-24 object-contain drop-shadow-2xl" />
          <div className="flex-1">
            <h1 className="text-2xl lg:text-3xl font-bold text-white mb-2">
              {companyInfo?.companyName || "Volkov Company"}
            </h1>
            <p className="text-white/70 text-sm lg:text-base max-w-2xl leading-relaxed">
              {companyInfo?.description || "A premier enterprise specializing in strategic investments, asset management, and financial operations."}
            </p>
            {companyInfo?.foundedDate && (
              <Badge variant="outline" className="mt-3 border-white/20 text-white/80">
                Est. {companyInfo.foundedDate}
              </Badge>
            )}
            {companyInfo?.location && (
              <Badge variant="outline" className="mt-3 ml-2 border-white/20 text-white/80">
                {companyInfo.location}
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="card-hover border-border/60">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Total Capital</p>
                <p className="text-xl lg:text-2xl font-bold number-format">
                  {statsLoading ? <Skeleton className="h-8 w-24" /> : formatMoney(stats?.totalCapital || 0)}
                </p>
                <p className="text-[10px] text-muted-foreground number-format">
                  {stats ? formatMoneyFull(stats.totalCapital) : ""}
                </p>
              </div>
              <div className="h-10 w-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover border-border/60">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Total Cash</p>
                <p className="text-xl lg:text-2xl font-bold number-format">
                  {statsLoading ? <Skeleton className="h-8 w-24" /> : formatMoney(stats?.totalCash || 0)}
                </p>
                <p className="text-[10px] text-muted-foreground number-format">
                  {stats ? formatMoneyFull(stats.totalCash) : ""}
                </p>
              </div>
              <div className="h-10 w-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
                <Wallet className="h-5 w-5 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover border-border/60">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Partners</p>
                <p className="text-xl lg:text-2xl font-bold">
                  {statsLoading ? <Skeleton className="h-8 w-12" /> : stats?.activePartners || 0}
                </p>
                <p className="text-[10px] text-muted-foreground">Active members</p>
              </div>
              <div className="h-10 w-10 rounded-xl bg-[var(--volkov-accent)]/10 flex items-center justify-center">
                <Users className="h-5 w-5 text-[var(--volkov-accent)]" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover border-border/60">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Pending</p>
                <p className="text-xl lg:text-2xl font-bold">
                  {(pendingActivations?.length || 0) + (pendingApprovals?.length || 0)}
                </p>
                <p className="text-[10px] text-muted-foreground">Need action</p>
              </div>
              <div className="h-10 w-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
                <Activity className="h-5 w-5 text-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Partners Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-[var(--volkov-accent)]" />
            Company Leadership
          </h2>
          <Link to="/partners">
            <Button variant="ghost" size="sm" className="gap-1 text-xs">
              View All <ArrowRight className="h-3 w-3" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {activePartners?.map((p) => (
            <Link to={`/partners/${p.partners.id}`} key={p.partners.id}>
              <Card className="card-hover border-border/60 overflow-hidden group cursor-pointer">
                <CardContent className="p-4 flex flex-col items-center text-center">
                  <div className="relative mb-3">
                    <div className="h-16 w-16 rounded-full overflow-hidden border-2 border-border group-hover:border-[var(--volkov-accent)]/50 transition-colors">
                      <img
                        src={p.partners.discordAvatar || `/avatar-${p.partners.displayName.toLowerCase()}.jpg`}
                        alt={p.partners.displayName}
                        className="h-full w-full object-cover"
                        onError={(e) => { (e.target as HTMLImageElement).src = "/avatar-volkov.jpg"; }}
                      />
                    </div>
                    {p.company_roles && (
                      <div
                        className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full border-2 border-background flex items-center justify-center"
                        style={{ backgroundColor: p.company_roles.color || "#e94560" }}
                      >
                        <Crown className="h-2.5 w-2.5 text-white" />
                      </div>
                    )}
                  </div>
                  <p className="font-bold text-sm">{p.partners.displayName}</p>
                  {p.company_roles && (
                    <Badge
                      variant="outline"
                      className="mt-1 text-[10px]"
                      style={{ borderColor: p.company_roles.color || undefined, color: p.company_roles.color || undefined }}
                    >
                      {p.company_roles.displayName}
                    </Badge>
                  )}
                  <p className="text-[10px] text-muted-foreground mt-1 font-mono">
                    {p.partners.discordUsername}
                  </p>
                  <div className="mt-2 pt-2 border-t border-border/50 w-full">
                    <div className="flex justify-between text-[10px]">
                      <span className="text-muted-foreground">Capital</span>
                      <span className="font-semibold number-format">{formatMoney(p.partners.totalCapital)}</span>
                    </div>
                    <div className="flex justify-between text-[10px] mt-0.5">
                      <span className="text-muted-foreground">Cash</span>
                      <span className="font-semibold number-format text-blue-500">{formatMoney(p.partners.totalCash)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent Activity & Testimonials */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <Card className="border-border/60">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Activity className="h-4 w-4 text-[var(--volkov-accent)]" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {recentLogs && recentLogs.length > 0 ? (
                recentLogs.slice(0, 8).map((log) => (
                  <div
                    key={log.logs.id}
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent/50 transition-colors"
                  >
                    <div className={`h-8 w-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      log.logs.type.includes("deposit")
                        ? "bg-emerald-500/10"
                        : log.logs.type.includes("withdrawal")
                        ? "bg-red-500/10"
                        : "bg-blue-500/10"
                    }`}>
                      {log.logs.type.includes("deposit") ? (
                        <TrendingUp className="h-4 w-4 text-emerald-500" />
                      ) : log.logs.type.includes("withdrawal") ? (
                        <TrendingDown className="h-4 w-4 text-red-500" />
                      ) : (
                        <Activity className="h-4 w-4 text-blue-500" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">{log.logs.description}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {log.logs.createdAt ? new Date(log.logs.createdAt).toLocaleDateString("en-US") : ""}
                      </p>
                    </div>
                    {log.logs.amount && (
                      <span className={`text-xs font-semibold number-format ${
                        log.logs.type.includes("deposit") ? "text-emerald-500" : "text-red-500"
                      }`}>
                        {log.logs.type.includes("deposit") ? "+" : "-"}{formatMoney(log.logs.amount)}
                      </span>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-xs text-muted-foreground text-center py-8">No recent activity</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Testimonials */}
        <Card className="border-border/60">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <MessageSquareQuote className="h-4 w-4 text-[var(--volkov-accent)]" />
                Reviews & Opinions
              </CardTitle>
              <Link to="/testimonials">
                <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
                  All <ArrowRight className="h-3 w-3" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {testimonials && testimonials.length > 0 ? (
                testimonials.slice(0, 6).map((t) => (
                  <div key={t.id} className="p-3 rounded-lg bg-accent/30 border border-border/40">
                    <div className="flex items-center gap-2 mb-1.5">
                      <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-[10px] font-bold">{t.name.charAt(0)}</span>
                      </div>
                      <span className="text-xs font-semibold">{t.name}</span>
                      <div className="flex gap-0.5 ml-auto">
                        {Array.from({ length: t.rating }).map((_, i) => (
                          <Star key={i} className="h-3 w-3 fill-amber-400 text-amber-400" />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{t.content}</p>
                    {t.discordUsername && (
                      <p className="text-[10px] text-muted-foreground/60 mt-1 font-mono">@{t.discordUsername}</p>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-xs text-muted-foreground text-center py-8">No reviews yet</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
