import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { UserPlus, CheckCircle, XCircle, Clock } from "lucide-react";

export default function ActivationRequests() {
  const { data: requests } = trpc.activation.list.useQuery();
  const { data: companyRoles } = trpc.companyRole.list.useQuery();
  const { data: permissionRoles } = trpc.permissionRole.list.useQuery();
  const utils = trpc.useUtils();

  const [approveData, setApproveData] = useState<{ id: number; companyRoleId: string; permissionRoleId: string } | null>(null);

  const approve = trpc.activation.approve.useMutation({
    onSuccess: () => { utils.activation.list.invalidate(); utils.partner.list.invalidate(); setApproveData(null); },
  });
  const reject = trpc.activation.reject.useMutation({
    onSuccess: () => utils.activation.list.invalidate(),
  });

  const pending = requests?.filter((r) => r.status === "pending") || [];
  const processed = requests?.filter((r) => r.status !== "pending") || [];

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold flex items-center gap-2">
        <UserPlus className="h-5 w-5 text-[var(--volkov-accent)]" />
        Activation Requests
      </h1>

      <Card className="border-border/60">
        <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Clock className="h-4 w-4 text-amber-500" /> Pending ({pending.length})</CardTitle></CardHeader>
        <CardContent>
          {pending.length > 0 ? pending.map((r) => (
            <div key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-amber-500/5 border border-amber-500/20 mb-2">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-sm font-bold">{r.displayName.charAt(0)}</span>
                </div>
                <div>
                  <p className="text-sm font-semibold">{r.displayName}</p>
                  <p className="text-[10px] text-muted-foreground font-mono">@{r.discordUsername}</p>
                  {r.discordId && <p className="text-[10px] text-muted-foreground font-mono">ID: {r.discordId}</p>}
                </div>
              </div>
              <div className="flex gap-2">
                <Dialog open={approveData?.id === r.id} onOpenChange={(open) => !open && setApproveData(null)}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="gap-1 bg-emerald-500 hover:bg-emerald-600" onClick={() => setApproveData({ id: r.id, companyRoleId: "", permissionRoleId: "" })}>
                      <CheckCircle className="h-3.5 w-3.5" /> Approve
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm">
                    <DialogHeader><DialogTitle>Assign Roles</DialogTitle></DialogHeader>
                    <div className="space-y-3 pt-2">
                      <div>
                        <Label className="text-xs">Company Role</Label>
                        <Select onValueChange={(v) => setApproveData(prev => prev ? { ...prev, companyRoleId: v } : null)}>
                          <SelectTrigger><SelectValue placeholder="Select role" /></SelectTrigger>
                          <SelectContent>{companyRoles?.map((cr) => <SelectItem key={cr.id} value={String(cr.id)}>{cr.displayName}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-xs">Permission Role</Label>
                        <Select onValueChange={(v) => setApproveData(prev => prev ? { ...prev, permissionRoleId: v } : null)}>
                          <SelectTrigger><SelectValue placeholder="Select role" /></SelectTrigger>
                          <SelectContent>{permissionRoles?.map((pr) => <SelectItem key={pr.id} value={String(pr.id)}>{pr.displayName}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                      <Button className="w-full" onClick={() => {
                        if (approveData) approve.mutate({
                          id: approveData.id,
                          reviewedBy: 1,
                          companyRoleId: approveData.companyRoleId ? Number(approveData.companyRoleId) : undefined,
                          permissionRoleId: approveData.permissionRoleId ? Number(approveData.permissionRoleId) : undefined,
                        });
                      }}>Confirm Approval</Button>
                    </div>
                  </DialogContent>
                </Dialog>
                <Button size="sm" variant="outline" className="gap-1 text-red-500" onClick={() => reject.mutate({ id: r.id, reviewedBy: 1 })}>
                  <XCircle className="h-3.5 w-3.5" /> Reject
                </Button>
              </div>
            </div>
          )) : <p className="text-xs text-muted-foreground text-center py-6">No pending requests</p>}
        </CardContent>
      </Card>

      {processed.length > 0 && (
        <Card className="border-border/60">
          <CardHeader className="pb-2"><CardTitle className="text-sm">Processed</CardTitle></CardHeader>
          <CardContent>
            {processed.map((r) => (
              <div key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-accent/20 mb-2">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-xs font-bold">{r.displayName.charAt(0)}</span>
                  </div>
                  <div>
                    <p className="text-xs font-medium">{r.displayName}</p>
                    <p className="text-[10px] text-muted-foreground font-mono">@{r.discordUsername}</p>
                  </div>
                </div>
                <Badge variant={r.status === "approved" ? "default" : "secondary"}>
                  {r.status}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
