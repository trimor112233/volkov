import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ClipboardList, TrendingUp, TrendingDown, ArrowLeftRight, Download, Filter } from "lucide-react";

function formatMoney(value: number | string) {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0";
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
  return num.toLocaleString("en-US");
}

const typeLabels: Record<string, string> = {
  capital_deposit: "Capital Deposit",
  capital_withdrawal: "Capital Withdrawal",
  cash_deposit: "Cash Deposit",
  cash_withdrawal: "Cash Withdrawal",
  cash_transfer: "Cash Transfer",
  asset_added: "Asset Added",
  asset_transferred: "Asset Transferred",
  partner_added: "Partner Added",
  partner_updated: "Partner Updated",
  role_changed: "Role Changed",
  company_updated: "Company Updated",
  approval_requested: "Approval Requested",
  approval_approved: "Approval Approved",
  approval_rejected: "Approval Rejected",
  login: "Login",
  logout: "Logout",
  note_added: "Note Added",
  proof_added: "Proof Added",
  testimonial_added: "Review Added",
};

export default function Logs() {
  const { data: logs } = trpc.log.list.useQuery();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const filtered = logs?.filter((l) => {
    const matchesSearch = !search || l.logs.description.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === "all" || l.logs.type === filter;
    return matchesSearch && matchesFilter;
  });

  const handleExport = () => {
    if (!filtered) return;
    const csv = [
      ["Date", "Type", "Partner", "Amount", "Description", "Details"].join(","),
      ...filtered.map((l) => [
        l.logs.createdAt ? new Date(l.logs.createdAt).toISOString() : "",
        typeLabels[l.logs.type] || l.logs.type,
        l.partners?.displayName || "",
        l.logs.amount || "",
        `"${l.logs.description}"`,
        `"${l.logs.details || ""}"`,
      ].join(",")),
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `volkov-logs-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <ClipboardList className="h-5 w-5 text-[var(--volkov-accent)]" />
          Activity Logs
        </h1>
        <Button variant="outline" size="sm" className="gap-1" onClick={handleExport}>
          <Download className="h-4 w-4" /> Export CSV
        </Button>
      </div>

      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search logs..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Select onValueChange={setFilter} defaultValue="all">
          <SelectTrigger className="w-40"><SelectValue placeholder="Filter" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="capital_deposit">Capital Deposit</SelectItem>
            <SelectItem value="capital_withdrawal">Capital Withdrawal</SelectItem>
            <SelectItem value="cash_deposit">Cash Deposit</SelectItem>
            <SelectItem value="cash_withdrawal">Cash Withdrawal</SelectItem>
            <SelectItem value="cash_transfer">Cash Transfer</SelectItem>
            <SelectItem value="asset_added">Asset Added</SelectItem>
            <SelectItem value="partner_added">Partner Added</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card className="border-border/60">
        <CardContent className="p-0">
          <div className="divide-y divide-border/50">
            {filtered && filtered.length > 0 ? filtered.map((log) => (
              <div key={log.logs.id} className="flex items-center gap-3 p-3 hover:bg-accent/30 transition-colors">
                <div className={`h-9 w-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  log.logs.type.includes("deposit") ? "bg-emerald-500/10" :
                  log.logs.type.includes("withdrawal") || log.logs.type.includes("rejected") ? "bg-red-500/10" :
                  log.logs.type.includes("transfer") ? "bg-blue-500/10" :
                  "bg-[var(--volkov-accent)]/10"
                }`}>
                  {log.logs.type.includes("deposit") ? <TrendingUp className="h-4 w-4 text-emerald-500" /> :
                   log.logs.type.includes("withdrawal") ? <TrendingDown className="h-4 w-4 text-red-500" /> :
                   log.logs.type.includes("transfer") ? <ArrowLeftRight className="h-4 w-4 text-blue-500" /> :
                   <ClipboardList className="h-4 w-4 text-[var(--volkov-accent)]" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-xs font-medium truncate">{log.logs.description}</p>
                    <Badge variant="outline" className="text-[9px] h-5">{typeLabels[log.logs.type] || log.logs.type}</Badge>
                  </div>
                  {log.logs.details && <p className="text-[10px] text-muted-foreground truncate">{log.logs.details}</p>}
                  <p className="text-[10px] text-muted-foreground">
                    {log.logs.createdAt ? new Date(log.logs.createdAt).toLocaleString("en-US") : ""}
                    {log.partners && ` | ${log.partners.displayName}`}
                  </p>
                </div>
                {log.logs.amount && (
                  <span className={`text-xs font-bold number-format flex-shrink-0 ${
                    log.logs.type.includes("deposit") || log.logs.type.includes("approved") ? "text-emerald-500" :
                    log.logs.type.includes("withdrawal") || log.logs.type.includes("rejected") ? "text-red-500" :
                    "text-blue-500"
                  }`}>
                    {log.logs.type.includes("deposit") || log.logs.type.includes("approved") ? "+" :
                     log.logs.type.includes("withdrawal") || log.logs.type.includes("rejected") ? "-" : ""}
                    {formatMoney(log.logs.amount)}
                  </span>
                )}
              </div>
            )) : <p className="text-xs text-muted-foreground text-center py-12">No logs found</p>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
