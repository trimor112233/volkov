import { useParams, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ArrowLeft,
  Crown,
  Wallet,
  TrendingUp,
  TrendingDown,
  Car,
  Shield,
} from "lucide-react";

function formatMoney(value: number | string) {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0";
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
  return num.toLocaleString("en-US");
}

export default function PartnerDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const partnerId = Number(id);

  const { data: partner, isLoading } = trpc.partner.getById.useQuery({ id: partnerId });
  const { data: partnerAssetsData } = trpc.asset.listByPartner.useQuery({ partnerId });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!partner) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">Partner not found</p>
        <Button variant="ghost" onClick={() => navigate("/partners")} className="mt-4">
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to Partners
        </Button>
      </div>
    );
  }

  const p = partner.partners;
  const cr = partner.company_roles;
  const pr = partner.permission_roles;
  const partnerAssets = partnerAssetsData || [];

  const assetsByType: Record<string, typeof partnerAssets> = {
    vehicles: partnerAssets.filter((a) => a.assetType === "vehicles"),
    real_estate: partnerAssets.filter((a) => a.assetType === "real_estate"),
    equipment: partnerAssets.filter((a) => a.assetType === "equipment"),
    other: partnerAssets.filter((a) => a.assetType === "other"),
  };

  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" onClick={() => navigate("/partners")}>
        <ArrowLeft className="h-4 w-4 mr-1" /> Back
      </Button>

      {/* Profile Header */}
      <Card className="border-border/60 overflow-hidden">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="relative">
              <div className="h-24 w-24 rounded-full overflow-hidden border-2 border-border">
                <img
                  src={p.discordAvatar || `/avatar-${p.displayName.toLowerCase()}.jpg`}
                  alt={p.displayName}
                  className="h-full w-full object-cover"
                  onError={(e) => { (e.target as HTMLImageElement).src = "/avatar-volkov.jpg"; }}
                />
              </div>
              {cr && (
                <div
                  className="absolute -bottom-1 -right-1 h-7 w-7 rounded-full border-2 border-background flex items-center justify-center"
                  style={{ backgroundColor: cr.color || "#e94560" }}
                >
                  <Crown className="h-3.5 w-3.5 text-white" />
                </div>
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="text-2xl font-bold">{p.displayName}</h1>
                <Badge variant={p.isActive ? "default" : "secondary"}>
                  {p.isActive ? "Active" : "Inactive"}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground font-mono mt-1">@{p.discordUsername}</p>
              {p.discordId && <p className="text-xs text-muted-foreground font-mono">ID: {p.discordId}</p>}
              <div className="flex gap-2 mt-3 flex-wrap">
                {cr && (
                  <Badge variant="outline" style={{ borderColor: cr.color || undefined, color: cr.color || undefined }}>
                    {cr.displayName}
                  </Badge>
                )}
                {pr && (
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Shield className="h-3 w-3" />
                    {pr.displayName}
                  </Badge>
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 w-full md:w-auto">
              <Card className="bg-emerald-500/5 border-emerald-500/20">
                <CardContent className="p-3 text-center">
                  <p className="text-[10px] text-muted-foreground">Total Capital</p>
                  <p className="text-xl font-bold number-format text-emerald-500">{formatMoney(p.totalCapital)}</p>
                  <p className="text-[10px] text-muted-foreground number-format">{Number(p.totalCapital).toLocaleString("en-US")}</p>
                </CardContent>
              </Card>
              <Card className="bg-blue-500/5 border-blue-500/20">
                <CardContent className="p-3 text-center">
                  <p className="text-[10px] text-muted-foreground">Total Cash</p>
                  <p className="text-xl font-bold number-format text-blue-500">{formatMoney(p.totalCash)}</p>
                  <p className="text-[10px] text-muted-foreground number-format">{Number(p.totalCash).toLocaleString("en-US")}</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="transactions" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 lg:w-auto lg:inline-flex">
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="assets">
            <Car className="h-3.5 w-3.5 mr-1" /> Assets
          </TabsTrigger>
        </TabsList>

        <TabsContent value="transactions" className="space-y-4">
          {/* Capital Transactions */}
          <Card className="border-border/60">
            <CardContent className="p-4">
              <h3 className="text-sm font-semibold flex items-center gap-2 mb-3">
                <TrendingUp className="h-4 w-4 text-emerald-500" />
                Capital Transactions
              </h3>
              {partner.capitalTransactions && partner.capitalTransactions.length > 0 ? (
                <div className="space-y-2">
                  {partner.capitalTransactions.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-accent/50 transition-colors">
                      <div className="flex items-center gap-2">
                        <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${tx.type === "deposit" ? "bg-emerald-500/10" : "bg-red-500/10"}`}>
                          {tx.type === "deposit" ? <TrendingUp className="h-4 w-4 text-emerald-500" /> : <TrendingDown className="h-4 w-4 text-red-500" />}
                        </div>
                        <div>
                          <p className="text-xs font-medium capitalize">{tx.type}</p>
                          <p className="text-[10px] text-muted-foreground">{tx.note || "No note"}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-sm font-bold number-format ${tx.type === "deposit" ? "text-emerald-500" : "text-red-500"}`}>
                          {tx.type === "deposit" ? "+" : "-"}{formatMoney(tx.amount)}
                        </p>
                        <p className="text-[10px] text-muted-foreground">{tx.createdAt ? new Date(tx.createdAt).toLocaleDateString("en-US") : ""}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground text-center py-6">No capital transactions</p>
              )}
            </CardContent>
          </Card>

          {/* Cash Transactions */}
          <Card className="border-border/60">
            <CardContent className="p-4">
              <h3 className="text-sm font-semibold flex items-center gap-2 mb-3">
                <Wallet className="h-4 w-4 text-blue-500" />
                Cash Transactions
              </h3>
              {partner.cashTransactions && partner.cashTransactions.length > 0 ? (
                <div className="space-y-2">
                  {partner.cashTransactions.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-accent/50 transition-colors">
                      <div className="flex items-center gap-2">
                        <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${
                          tx.type === "deposit" ? "bg-emerald-500/10" : tx.type === "withdrawal" ? "bg-red-500/10" : "bg-blue-500/10"
                        }`}>
                          {tx.type === "deposit" ? <TrendingUp className="h-4 w-4 text-emerald-500" /> :
                           tx.type === "withdrawal" ? <TrendingDown className="h-4 w-4 text-red-500" /> :
                           <Wallet className="h-4 w-4 text-blue-500" />}
                        </div>
                        <div>
                          <p className="text-xs font-medium capitalize">{tx.type}</p>
                          <p className="text-[10px] text-muted-foreground">{tx.note || "No note"}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-sm font-bold number-format ${
                          tx.type === "deposit" ? "text-emerald-500" : tx.type === "withdrawal" ? "text-red-500" : "text-blue-500"
                        }`}>
                          {tx.type === "deposit" ? "+" : tx.type === "withdrawal" ? "-" : ""}{formatMoney(tx.amount)}
                        </p>
                        <p className="text-[10px] text-muted-foreground">{tx.createdAt ? new Date(tx.createdAt).toLocaleDateString("en-US") : ""}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground text-center py-6">No cash transactions</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="assets" className="space-y-4">
          {Object.entries(assetsByType).map(([type, assets]) => (
            assets.length > 0 && (
              <Card key={type} className="border-border/60">
                <CardContent className="p-4">
                  <h3 className="text-sm font-semibold capitalize flex items-center gap-2 mb-3">
                    <Car className="h-4 w-4 text-[var(--volkov-accent)]" />
                    {type.replace("_", " ")}
                  </h3>
                  <div className="space-y-2">
                    {assets.map((a) => (
                      <div key={a.id} className="flex items-center justify-between p-2 rounded-lg bg-accent/30">
                        <div>
                          <p className="text-xs font-medium">{a.assetName}</p>
                          <p className="text-[10px] text-muted-foreground font-mono">ID: {a.assetIdCode}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )
          ))}
          {Object.values(assetsByType).every((a) => a.length === 0) && (
            <p className="text-xs text-muted-foreground text-center py-6">No assets</p>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
