import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Car, Plus, ArrowRightLeft } from "lucide-react";

export default function Assets() {
  const { data: assetsData } = trpc.asset.list.useQuery();
  const { data: partners } = trpc.partner.list.useQuery();
  const utils = trpc.useUtils();

  const [showAdd, setShowAdd] = useState(false);
  const [showTransfer, setShowTransfer] = useState(false);
  const [newAsset, setNewAsset] = useState({ partnerId: "", assetName: "", assetType: "", assetIdCode: "", description: "" });
  const [transferData, setTransferData] = useState({ assetId: "", fromPartnerId: "", toPartnerId: "", toPartnerName: "", note: "" });

  const createAsset = trpc.asset.create.useMutation({
    onSuccess: () => { utils.asset.list.invalidate(); setShowAdd(false); setNewAsset({ partnerId: "", assetName: "", assetType: "", assetIdCode: "", description: "" }); },
  });

  const transferAsset = trpc.asset.transfer.useMutation({
    onSuccess: () => { utils.asset.list.invalidate(); setShowTransfer(false); setTransferData({ assetId: "", fromPartnerId: "", toPartnerId: "", toPartnerName: "", note: "" }); },
  });

  const assetTypes = ["vehicles", "real_estate", "equipment", "other"];

  const byType = (type: string) => assetsData?.filter((a) => a.assets.assetType === type) || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <Car className="h-5 w-5 text-[var(--volkov-accent)]" />
          Assets Management
        </h1>
        <div className="flex gap-2">
          <Dialog open={showTransfer} onOpenChange={setShowTransfer}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1"><ArrowRightLeft className="h-4 w-4" /> Transfer</Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader><DialogTitle>Transfer Asset Ownership</DialogTitle></DialogHeader>
              <div className="space-y-3 pt-2">
                <div>
                  <Label className="text-xs">Asset</Label>
                  <Select onValueChange={(v) => { const a = assetsData?.find((x) => String(x.assets.id) === v); setTransferData({ ...transferData, assetId: v, fromPartnerId: a ? String(a.assets.partnerId) : "" }); }}>
                    <SelectTrigger><SelectValue placeholder="Select asset" /></SelectTrigger>
                    <SelectContent>
                      {assetsData?.map((a) => (
                        <SelectItem key={a.assets.id} value={String(a.assets.id)}>{a.assets.assetName} ({a.assets.assetIdCode})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">To Partner</Label>
                  <Select onValueChange={(v) => { const p = partners?.find((x) => String(x.partners.id) === v); setTransferData({ ...transferData, toPartnerId: v, toPartnerName: p?.partners.displayName || "" }); }}>
                    <SelectTrigger><SelectValue placeholder="Select partner" /></SelectTrigger>
                    <SelectContent>
                      {partners?.map((p) => (
                        <SelectItem key={p.partners.id} value={String(p.partners.id)}>{p.partners.displayName}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Note</Label>
                  <Textarea value={transferData.note} onChange={(e) => setTransferData({ ...transferData, note: e.target.value })} placeholder="Reason for transfer..." rows={2} />
                </div>
                <Button className="w-full" onClick={() => transferAsset.mutate({
                  assetId: Number(transferData.assetId),
                  fromPartnerId: Number(transferData.fromPartnerId),
                  toPartnerId: Number(transferData.toPartnerId),
                  toPartnerName: transferData.toPartnerName,
                  note: transferData.note,
                })} disabled={!transferData.assetId || !transferData.toPartnerId}>Transfer Asset</Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={showAdd} onOpenChange={setShowAdd}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1"><Plus className="h-4 w-4" /> Add Asset</Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader><DialogTitle>Add New Asset</DialogTitle></DialogHeader>
              <div className="space-y-3 pt-2">
                <div>
                  <Label className="text-xs">Owner</Label>
                  <Select onValueChange={(v) => setNewAsset({ ...newAsset, partnerId: v })}>
                    <SelectTrigger><SelectValue placeholder="Select partner" /></SelectTrigger>
                    <SelectContent>
                      {partners?.map((p) => (
                        <SelectItem key={p.partners.id} value={String(p.partners.id)}>{p.partners.displayName}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Asset Name</Label>
                  <Input value={newAsset.assetName} onChange={(e) => setNewAsset({ ...newAsset, assetName: e.target.value })} placeholder="e.g. Ford F-150" />
                </div>
                <div>
                  <Label className="text-xs">Asset Type</Label>
                  <Select onValueChange={(v) => setNewAsset({ ...newAsset, assetType: v })}>
                    <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vehicles">Vehicles</SelectItem>
                      <SelectItem value="real_estate">Real Estate</SelectItem>
                      <SelectItem value="equipment">Equipment</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Asset ID Code</Label>
                  <Input value={newAsset.assetIdCode} onChange={(e) => setNewAsset({ ...newAsset, assetIdCode: e.target.value })} placeholder="e.g. VEH-001" />
                </div>
                <div>
                  <Label className="text-xs">Description</Label>
                  <Textarea value={newAsset.description} onChange={(e) => setNewAsset({ ...newAsset, description: e.target.value })} placeholder="Optional details..." rows={2} />
                </div>
                <Button className="w-full" onClick={() => createAsset.mutate({
                  partnerId: Number(newAsset.partnerId),
                  assetName: newAsset.assetName,
                  assetType: newAsset.assetType as "vehicles" | "real_estate" | "equipment" | "other",
                  assetIdCode: newAsset.assetIdCode,
                  description: newAsset.description,
                })} disabled={!newAsset.partnerId || !newAsset.assetName || !newAsset.assetType || !newAsset.assetIdCode}>Add Asset</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          {assetTypes.map((t) => (
            <TabsTrigger key={t} value={t} className="capitalize">{t.replace("_", " ")}</TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all" className="space-y-2">
          <AssetsTable assets={assetsData || []} partners={partners || []} />
        </TabsContent>
        {assetTypes.map((type) => (
          <TabsContent key={type} value={type} className="space-y-2">
            <AssetsTable assets={byType(type)} partners={partners || []} />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

function AssetsTable({ assets, partners }: { assets: { assets: { id: number; partnerId: number; assetName: string; assetType: string; assetIdCode: string; description: string | null }; }[]; partners: { partners: { id: number; displayName: string } }[] }) {
  if (assets.length === 0) return <p className="text-xs text-muted-foreground text-center py-8">No assets in this category</p>;

  return (
    <Card className="border-border/60">
      <CardContent className="p-0">
        <div className="divide-y divide-border/50">
          {assets.map((a) => {
            const owner = partners.find((p) => p.partners.id === a.assets.partnerId);
            return (
              <div key={a.assets.id} className="flex items-center justify-between p-3 hover:bg-accent/30 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="h-9 w-9 rounded-lg bg-[var(--volkov-accent)]/10 flex items-center justify-center text-lg">
                    {a.assets.assetType === "vehicles" ? "🚗" : a.assets.assetType === "real_estate" ? "🏢" : a.assets.assetType === "equipment" ? "⚙️" : "📦"}
                  </div>
                  <div>
                    <p className="text-xs font-medium">{a.assets.assetName}</p>
                    <p className="text-[10px] text-muted-foreground font-mono">ID: {a.assets.assetIdCode}</p>
                    {a.assets.description && <p className="text-[10px] text-muted-foreground">{a.assets.description}</p>}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs font-medium">{owner?.partners.displayName || "Unknown"}</p>
                  <p className="text-[10px] text-muted-foreground capitalize">{a.assets.assetType.replace("_", " ")}</p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
