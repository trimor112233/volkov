import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Banknote, Plus, TrendingUp, TrendingDown, ArrowLeftRight } from "lucide-react";

function formatMoney(value: number | string) {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0";
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
  return num.toLocaleString("en-US");
}

export default function Cash() {
  const { data: partners } = trpc.partner.list.useQuery();
  const { data: transactions } = trpc.cash.list.useQuery();
  const { data: stats } = trpc.partner.getStats.useQuery();
  const utils = trpc.useUtils();

  const [showForm, setShowForm] = useState(false);
  const [formType, setFormType] = useState<"deposit" | "withdrawal" | "transfer">("deposit");
  const [formData, setFormData] = useState({ partnerId: "", amount: "", note: "", toPartnerId: "" });

  const depositMut = trpc.cash.deposit.useMutation({
    onSuccess: () => { invalidateAll(); setShowForm(false); resetForm(); },
  });
  const withdrawMut = trpc.cash.withdraw.useMutation({
    onSuccess: () => { invalidateAll(); setShowForm(false); resetForm(); },
  });
  const transferMut = trpc.cash.transfer.useMutation({
    onSuccess: () => { invalidateAll(); setShowForm(false); resetForm(); },
  });

  const invalidateAll = () => {
    utils.cash.list.invalidate();
    utils.partner.list.invalidate();
    utils.partner.getStats.invalidate();
    utils.log.list.invalidate();
  };

  const resetForm = () => setFormData({ partnerId: "", amount: "", note: "", toPartnerId: "" });

  const handleSubmit = () => {
    if (!formData.partnerId || !formData.amount) return;
    const payload = { partnerId: Number(formData.partnerId), amount: formData.amount, note: formData.note };
    if (formType === "deposit") depositMut.mutate(payload);
    else if (formType === "withdrawal") withdrawMut.mutate(payload);
    else if (formData.toPartnerId) transferMut.mutate({ ...payload, transferToPartnerId: Number(formData.toPartnerId) });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <Banknote className="h-5 w-5 text-[var(--volkov-accent)]" />
          Cash Management
        </h1>
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1"><Plus className="h-4 w-4" /> Cash Operation</Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Cash Transaction</DialogTitle></DialogHeader>
            <div className="space-y-3 pt-2">
              <Tabs value={formType} onValueChange={(v) => setFormType(v as typeof formType)}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="deposit" className="gap-1 text-xs"><TrendingUp className="h-3 w-3" /> Deposit</TabsTrigger>
                  <TabsTrigger value="withdrawal" className="gap-1 text-xs"><TrendingDown className="h-3 w-3" /> Withdraw</TabsTrigger>
                  <TabsTrigger value="transfer" className="gap-1 text-xs"><ArrowLeftRight className="h-3 w-3" /> Transfer</TabsTrigger>
                </TabsList>
              </Tabs>
              <div>
                <Label className="text-xs">{formType === "transfer" ? "From Partner" : "Partner"}</Label>
                <Select onValueChange={(v) => setFormData({ ...formData, partnerId: v })}>
                  <SelectTrigger><SelectValue placeholder="Select partner" /></SelectTrigger>
                  <SelectContent>
                    {partners?.map((p) => (
                      <SelectItem key={p.partners.id} value={String(p.partners.id)}>{p.partners.displayName}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {formType === "transfer" && (
                <div>
                  <Label className="text-xs">To Partner</Label>
                  <Select onValueChange={(v) => setFormData({ ...formData, toPartnerId: v })}>
                    <SelectTrigger><SelectValue placeholder="Select partner" /></SelectTrigger>
                    <SelectContent>
                      {partners?.filter((p) => String(p.partners.id) !== formData.partnerId).map((p) => (
                        <SelectItem key={p.partners.id} value={String(p.partners.id)}>{p.partners.displayName}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div>
                <Label className="text-xs">Amount</Label>
                <Input type="number" value={formData.amount} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} placeholder="0.00" />
              </div>
              <div>
                <Label className="text-xs">Note (optional)</Label>
                <Textarea value={formData.note} onChange={(e) => setFormData({ ...formData, note: e.target.value })} placeholder="Reason..." rows={2} />
              </div>
              <Button className="w-full" onClick={handleSubmit} disabled={!formData.partnerId || !formData.amount || (formType === "transfer" && !formData.toPartnerId)}>
                {formType === "deposit" ? "Deposit Cash" : formType === "withdrawal" ? "Withdraw Cash" : "Transfer Cash"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-border/60 bg-blue-500/5">
          <CardContent className="p-4">
            <p className="text-[10px] text-muted-foreground uppercase">Total Cash</p>
            <p className="text-2xl font-bold number-format text-blue-500">{formatMoney(stats?.totalCash || 0)}</p>
            <p className="text-[10px] text-muted-foreground number-format">{Number(stats?.totalCash || 0).toLocaleString("en-US")}</p>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="p-4">
            <p className="text-[10px] text-muted-foreground uppercase">Deposits</p>
            <p className="text-2xl font-bold number-format text-emerald-500">
              {formatMoney(transactions?.filter((t) => t.cash_transactions.type === "deposit").reduce((s, t) => s + Number(t.cash_transactions.amount), 0) || 0)}
            </p>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="p-4">
            <p className="text-[10px] text-muted-foreground uppercase">Withdrawals</p>
            <p className="text-2xl font-bold number-format text-red-500">
              {formatMoney(transactions?.filter((t) => t.cash_transactions.type === "withdrawal").reduce((s, t) => s + Number(t.cash_transactions.amount), 0) || 0)}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/60">
        <CardHeader className="pb-2"><CardTitle className="text-sm">Recent Cash Transactions</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-2">
            {transactions && transactions.length > 0 ? transactions.slice(0, 20).map((tx) => (
              <div key={tx.cash_transactions.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-accent/50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${
                    tx.cash_transactions.type === "deposit" ? "bg-emerald-500/10" :
                    tx.cash_transactions.type === "withdrawal" ? "bg-red-500/10" : "bg-blue-500/10"
                  }`}>
                    {tx.cash_transactions.type === "deposit" ? <TrendingUp className="h-4 w-4 text-emerald-500" /> :
                     tx.cash_transactions.type === "withdrawal" ? <TrendingDown className="h-4 w-4 text-red-500" /> :
                     <ArrowLeftRight className="h-4 w-4 text-blue-500" />}
                  </div>
                  <div>
                    <p className="text-xs font-medium">{tx.partners?.displayName || "Unknown"}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {tx.cash_transactions.type === "transfer" && tx.cash_transactions.transferToPartnerId
                        ? `Transfer to partner #${tx.cash_transactions.transferToPartnerId}`
                        : tx.cash_transactions.note || "No note"}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-bold number-format ${
                    tx.cash_transactions.type === "deposit" ? "text-emerald-500" :
                    tx.cash_transactions.type === "withdrawal" ? "text-red-500" : "text-blue-500"
                  }`}>
                    {tx.cash_transactions.type === "deposit" ? "+" : tx.cash_transactions.type === "withdrawal" ? "-" : ""}
                    {formatMoney(tx.cash_transactions.amount)}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{tx.cash_transactions.createdAt ? new Date(tx.cash_transactions.createdAt).toLocaleDateString("en-US") : ""}</p>
                </div>
              </div>
            )) : <p className="text-xs text-muted-foreground text-center py-6">No transactions</p>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
