import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings, Webhook, Users, ShieldCheck, Save } from "lucide-react";

export default function SettingsPage() {
  const { data: discordSettings } = trpc.discord.get.useQuery();
  const { data: companyRoles } = trpc.companyRole.list.useQuery();
  const { data: permissionRoles } = trpc.permissionRole.list.useQuery();
  const utils = trpc.useUtils();

  const [webhookUrl, setWebhookUrl] = useState("");
  const [webhookEnabled, setWebhookEnabled] = useState(false);

  const updateDiscord = trpc.discord.update.useMutation({
    onSuccess: () => utils.discord.get.invalidate(),
  });

  const handleSaveWebhook = () => {
    updateDiscord.mutate({ webhookUrl, isEnabled: webhookEnabled });
  };

  // Load current values
  useState(() => {
    if (discordSettings) {
      setWebhookUrl(discordSettings.webhookUrl || "");
      setWebhookEnabled(discordSettings.isEnabled || false);
    }
  });

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <h1 className="text-xl font-bold flex items-center gap-2">
        <Settings className="h-5 w-5 text-[var(--volkov-accent)]" />
        Settings
      </h1>

      <Tabs defaultValue="discord" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="discord" className="gap-1"><Webhook className="h-3.5 w-3.5" /> Discord</TabsTrigger>
          <TabsTrigger value="roles" className="gap-1"><Users className="h-3.5 w-3.5" /> Roles</TabsTrigger>
          <TabsTrigger value="permissions" className="gap-1"><ShieldCheck className="h-3.5 w-3.5" /> Permissions</TabsTrigger>
        </TabsList>

        <TabsContent value="discord" className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-2"><CardTitle className="text-sm">Discord Webhook</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Enable Notifications</p>
                  <p className="text-[10px] text-muted-foreground">Send logs to Discord channel</p>
                </div>
                <Switch checked={webhookEnabled} onCheckedChange={setWebhookEnabled} />
              </div>
              <div>
                <Label className="text-xs">Webhook URL</Label>
                <Input value={webhookUrl} onChange={(e) => setWebhookUrl(e.target.value)} placeholder="https://discord.com/api/webhooks/..." />
                <p className="text-[10px] text-muted-foreground mt-1">Create a webhook in your Discord server settings and paste the URL here.</p>
              </div>
              <Button size="sm" className="gap-1" onClick={handleSaveWebhook}><Save className="h-3.5 w-3.5" /> Save Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="roles" className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-2"><CardTitle className="text-sm">Company Roles</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2">
                {companyRoles?.map((role) => (
                  <div key={role.id} className="flex items-center justify-between p-2 rounded-lg bg-accent/20">
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 rounded-full" style={{ backgroundColor: role.color || undefined }} />
                      <span className="text-sm">{role.displayName}</span>
                      <span className="text-[10px] text-muted-foreground font-mono">({role.name})</span>
                    </div>
                    <span className="text-[10px] text-muted-foreground">Rank {role.rank}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="permissions" className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-2"><CardTitle className="text-sm">Permission Roles</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-3">
                {permissionRoles?.map((role) => (
                  <div key={role.id} className="p-3 rounded-lg bg-accent/20">
                    <p className="text-sm font-semibold">{role.displayName}</p>
                    <p className="text-[10px] text-muted-foreground mb-2">{role.description}</p>
                    <div className="flex flex-wrap gap-1">
                      {Object.entries({
                        "View Logs": role.canViewLogs,
                        "Add Capital": role.canAddCapital,
                        "Withdraw Capital": role.canWithdrawCapital,
                        "Add Cash": role.canAddCash,
                        "Withdraw Cash": role.canWithdrawCash,
                        "Transfer Cash": role.canTransferCash,
                        "Manage Partners": role.canManagePartners,
                        "Manage Roles": role.canManageRoles,
                        "Manage Company": role.canManageCompany,
                        "Manage Assets": role.canManageAssets,
                        "Approve Requests": role.canApproveRequests,
                        "Backup": role.canBackup,
                        "Own Cash Only": role.canEditOwnCashOnly,
                        "Own Data Only": role.canViewOwnDataOnly,
                      }).filter(([_, v]) => v).map(([name]) => (
                        <span key={name} className="text-[9px] px-1.5 py-0.5 rounded bg-primary/10">{name}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
