import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "react-router";
import { Users, Plus, Search, Crown } from "lucide-react";

function formatMoney(value: number | string) {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0";
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
  return num.toLocaleString("en-US");
}

export default function Partners() {
  const { data: partnersData, isLoading } = trpc.partner.list.useQuery();
  const { data: companyRoles } = trpc.companyRole.list.useQuery();
  const { data: permissionRoles } = trpc.permissionRole.list.useQuery();
  const utils = trpc.useUtils();

  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [newPartner, setNewPartner] = useState({
    displayName: "",
    discordUsername: "",
    discordId: "",
    companyRoleId: "",
    permissionRoleId: "",
    totalCapital: "0",
    totalCash: "0",
  });

  const createPartner = trpc.partner.create.useMutation({
    onSuccess: () => {
      utils.partner.list.invalidate();
      utils.partner.getStats.invalidate();
      setShowAdd(false);
      setNewPartner({ displayName: "", discordUsername: "", discordId: "", companyRoleId: "", permissionRoleId: "", totalCapital: "0", totalCash: "0" });
    },
  });

  const filtered = partnersData?.filter((p) =>
    p.partners.displayName.toLowerCase().includes(search.toLowerCase()) ||
    p.partners.discordUsername.toLowerCase().includes(search.toLowerCase())
  );

  const totalCapital = partnersData?.reduce((s, p) => s + Number(p.partners.totalCapital), 0) || 0;
  const totalCash = partnersData?.reduce((s, p) => s + Number(p.partners.totalCash), 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2">
            <Users className="h-5 w-5 text-[var(--volkov-accent)]" />
            Partners & Balances
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Total Capital: <span className="font-semibold text-emerald-500">{formatMoney(totalCapital)}</span> |{" "}
            Total Cash: <span className="font-semibold text-blue-500">{formatMoney(totalCash)}</span>
          </p>
        </div>
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1">
              <Plus className="h-4 w-4" /> Add Partner
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Partner</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 pt-2">
              <div>
                <Label className="text-xs">Display Name</Label>
                <Input value={newPartner.displayName} onChange={(e) => setNewPartner({ ...newPartner, displayName: e.target.value })} placeholder="e.g. John Doe" />
              </div>
              <div>
                <Label className="text-xs">Discord Username</Label>
                <Input value={newPartner.discordUsername} onChange={(e) => setNewPartner({ ...newPartner, discordUsername: e.target.value })} placeholder="e.g. johndoe" />
              </div>
              <div>
                <Label className="text-xs">Discord ID</Label>
                <Input value={newPartner.discordId} onChange={(e) => setNewPartner({ ...newPartner, discordId: e.target.value })} placeholder="e.g. 123456789" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Company Role</Label>
                  <Select onValueChange={(v) => setNewPartner({ ...newPartner, companyRoleId: v })}>
                    <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                    <SelectContent>
                      {companyRoles?.map((r) => (
                        <SelectItem key={r.id} value={String(r.id)}>{r.displayName}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Permission Role</Label>
                  <Select onValueChange={(v) => setNewPartner({ ...newPartner, permissionRoleId: v })}>
                    <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                    <SelectContent>
                      {permissionRoles?.map((r) => (
                        <SelectItem key={r.id} value={String(r.id)}>{r.displayName}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Initial Capital</Label>
                  <Input type="number" value={newPartner.totalCapital} onChange={(e) => setNewPartner({ ...newPartner, totalCapital: e.target.value })} />
                </div>
                <div>
                  <Label className="text-xs">Initial Cash</Label>
                  <Input type="number" value={newPartner.totalCash} onChange={(e) => setNewPartner({ ...newPartner, totalCash: e.target.value })} />
                </div>
              </div>
              <Button
                className="w-full"
                onClick={() => createPartner.mutate({
                  ...newPartner,
                  companyRoleId: newPartner.companyRoleId ? Number(newPartner.companyRoleId) : undefined,
                  permissionRoleId: newPartner.permissionRoleId ? Number(newPartner.permissionRoleId) : undefined,
                })}
                disabled={!newPartner.displayName || !newPartner.discordUsername}
              >
                Create Partner
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input className="pl-9" placeholder="Search partners..." value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="border-border/60"><CardContent className="p-4"><div className="h-24 animate-pulse bg-accent rounded" /></CardContent></Card>
          ))
        ) : filtered?.length === 0 ? (
          <p className="col-span-full text-center text-muted-foreground py-12">No partners found</p>
        ) : (
          filtered?.map((p) => (
            <Link to={`/partners/${p.partners.id}`} key={p.partners.id}>
              <Card className="card-hover border-border/60 cursor-pointer overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="h-12 w-12 rounded-full overflow-hidden border border-border flex-shrink-0">
                      <img
                        src={p.partners.discordAvatar || `/avatar-${p.partners.displayName.toLowerCase()}.jpg`}
                        alt={p.partners.displayName}
                        className="h-full w-full object-cover"
                        onError={(e) => { (e.target as HTMLImageElement).src = "/avatar-volkov.jpg"; }}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-sm truncate">{p.partners.displayName}</p>
                        {p.partners.isActive ? (
                          <span className="h-2 w-2 rounded-full bg-emerald-500" />
                        ) : (
                          <span className="h-2 w-2 rounded-full bg-red-500" />
                        )}
                      </div>
                      <p className="text-[10px] text-muted-foreground font-mono">@{p.partners.discordUsername}</p>
                      {p.company_roles && (
                        <Badge variant="outline" className="mt-1 text-[10px]" style={{ borderColor: p.company_roles.color || undefined, color: p.company_roles.color || undefined }}>
                          {p.company_roles.displayName}
                        </Badge>
                      )}
                    </div>
                    {p.company_roles && (
                      <Crown className="h-4 w-4 flex-shrink-0" style={{ color: p.company_roles.color || undefined }} />
                    )}
                  </div>
                  <div className="mt-3 pt-3 border-t border-border/50 grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-[10px] text-muted-foreground">Capital</p>
                      <p className="text-sm font-bold number-format text-emerald-500">{formatMoney(p.partners.totalCapital)}</p>
                      <p className="text-[10px] text-muted-foreground number-format">{Number(p.partners.totalCapital).toLocaleString("en-US")}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted-foreground">Cash</p>
                      <p className="text-sm font-bold number-format text-blue-500">{formatMoney(p.partners.totalCash)}</p>
                      <p className="text-[10px] text-muted-foreground number-format">{Number(p.partners.totalCash).toLocaleString("en-US")}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
