import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, ArrowLeft } from "lucide-react";

export default function Activate() {
  const navigate = useNavigate();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    displayName: "",
    discordUsername: "",
    discordId: "",
    discordAvatar: "",
    discordProfileUrl: "",
  });

  const createRequest = trpc.activation.create.useMutation({
    onSuccess: () => setSubmitted(true),
  });

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="max-w-md w-full border-border/60">
          <CardContent className="p-8 text-center space-y-4">
            <div className="h-16 w-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto">
              <CheckCircle className="h-8 w-8 text-emerald-500" />
            </div>
            <h2 className="text-xl font-bold">Request Submitted!</h2>
            <p className="text-sm text-muted-foreground">
              Your activation request has been sent to the company owner. You will be notified once your account is approved.
            </p>
            <Button variant="outline" className="gap-1" onClick={() => navigate("/")}>
              <ArrowLeft className="h-4 w-4" /> Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="max-w-md w-full border-border/60">
        <CardHeader className="text-center pb-2">
          <img src="/volkov-logo.png" alt="Volkov" className="h-16 w-16 object-contain mx-auto mb-3" />
          <CardTitle className="text-xl">Request Activation</CardTitle>
          <p className="text-xs text-muted-foreground">Fill in your details to request access to Volkov Company ERP</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-xs">Character Name</Label>
            <Input value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} placeholder="Your in-game character name" />
          </div>
          <div>
            <Label className="text-xs">Discord Username</Label>
            <Input value={form.discordUsername} onChange={(e) => setForm({ ...form, discordUsername: e.target.value })} placeholder="e.g. username" />
          </div>
          <div>
            <Label className="text-xs">Discord ID</Label>
            <Input value={form.discordId} onChange={(e) => setForm({ ...form, discordId: e.target.value })} placeholder="Your Discord user ID" />
          </div>
          <div>
            <Label className="text-xs">Discord Avatar URL (optional)</Label>
            <Input value={form.discordAvatar} onChange={(e) => setForm({ ...form, discordAvatar: e.target.value })} placeholder="https://cdn.discordapp.com/..." />
          </div>
          <div>
            <Label className="text-xs">Discord Profile URL (optional)</Label>
            <Input value={form.discordProfileUrl} onChange={(e) => setForm({ ...form, discordProfileUrl: e.target.value })} placeholder="https://discord.com/users/..." />
          </div>
          <Button
            className="w-full"
            onClick={() => createRequest.mutate(form)}
            disabled={!form.displayName || !form.discordUsername}
          >
            Submit Request
          </Button>
          <Button variant="ghost" className="w-full text-xs" onClick={() => navigate("/")}>
            Cancel
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
