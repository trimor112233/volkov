import { getDb } from "../api/queries/connection";
import {
  companyRoles,
  permissionRoles,
  partners,
  companyInfo,
  discordSettings,
  notes,
  testimonials,
} from "./schema";

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  // Seed company info
  const existingInfo = await db.select().from(companyInfo);
  if (existingInfo.length === 0) {
    await db.insert(companyInfo).values({
      companyName: "Volkov Company",
      description: "A premier enterprise specializing in strategic investments, asset management, and financial operations. Established with a vision to build lasting wealth through smart partnerships.",
      foundedDate: "2024",
      location: "Global",
      discordLink: "",
      primaryColor: "#1a1a2e",
      secondaryColor: "#16213e",
      accentColor: "#e94560",
    });
    console.log("Company info seeded");
  }

  // Seed company roles
  const existingRoles = await db.select().from(companyRoles);
  if (existingRoles.length === 0) {
    await db.insert(companyRoles).values([
      { name: "company_owner", displayName: "Company Owner", rank: 1, color: "#FFD700" },
      { name: "co_owner", displayName: "Co-Owner", rank: 2, color: "#C0C0C0" },
      { name: "founder", displayName: "Founder", rank: 3, color: "#CD7F32" },
      { name: "ceo", displayName: "CEO", rank: 4, color: "#e94560" },
      { name: "coo", displayName: "COO", rank: 5, color: "#0f3460" },
      { name: "cfo", displayName: "CFO", rank: 6, color: "#16c79a" },
      { name: "manager", displayName: "Manager", rank: 7, color: "#7b68ee" },
      { name: "supervisor", displayName: "Supervisor", rank: 8, color: "#4ecdc4" },
      { name: "member", displayName: "Member", rank: 9, color: "#95a5a6" },
    ]);
    console.log("Company roles seeded");
  }

  // Seed permission roles
  const existingPerms = await db.select().from(permissionRoles);
  if (existingPerms.length === 0) {
    await db.insert(permissionRoles).values([
      {
        name: "admin",
        displayName: "Admin",
        description: "Full control over everything",
        canViewLogs: true,
        canAddCapital: true,
        canWithdrawCapital: true,
        canAddCash: true,
        canWithdrawCash: true,
        canTransferCash: true,
        canManagePartners: true,
        canManageRoles: true,
        canManageCompany: true,
        canManageAssets: true,
        canApproveRequests: true,
        canBackup: true,
        canEditOwnCashOnly: false,
        canViewOwnDataOnly: false,
        canManageNotes: true,
        canManageProofs: true,
        canManageTestimonials: true,
      },
      {
        name: "supervisor",
        displayName: "Supervisor",
        description: "Can manage financial operations but not site settings or users",
        canViewLogs: true,
        canAddCapital: true,
        canWithdrawCapital: true,
        canAddCash: true,
        canWithdrawCash: true,
        canTransferCash: true,
        canManagePartners: false,
        canManageRoles: false,
        canManageCompany: false,
        canManageAssets: true,
        canApproveRequests: true,
        canBackup: false,
        canEditOwnCashOnly: false,
        canViewOwnDataOnly: false,
        canManageNotes: true,
        canManageProofs: true,
        canManageTestimonials: false,
      },
      {
        name: "accountant",
        displayName: "Accountant",
        description: "Can manage capital, cash, view logs, upload receipts",
        canViewLogs: true,
        canAddCapital: true,
        canWithdrawCapital: true,
        canAddCash: true,
        canWithdrawCash: true,
        canTransferCash: true,
        canManagePartners: false,
        canManageRoles: false,
        canManageCompany: false,
        canManageAssets: false,
        canApproveRequests: false,
        canBackup: false,
        canEditOwnCashOnly: false,
        canViewOwnDataOnly: false,
        canManageNotes: false,
        canManageProofs: true,
        canManageTestimonials: false,
      },
      {
        name: "editor",
        displayName: "Editor",
        description: "Can manage own cash only, view logs",
        canViewLogs: true,
        canAddCapital: false,
        canWithdrawCapital: false,
        canAddCash: true,
        canWithdrawCash: true,
        canTransferCash: false,
        canManagePartners: false,
        canManageRoles: false,
        canManageCompany: false,
        canManageAssets: false,
        canApproveRequests: false,
        canBackup: false,
        canEditOwnCashOnly: true,
        canViewOwnDataOnly: false,
        canManageNotes: false,
        canManageProofs: false,
        canManageTestimonials: false,
      },
      {
        name: "member",
        displayName: "Member",
        description: "Can only view own capital and cash",
        canViewLogs: false,
        canAddCapital: false,
        canWithdrawCapital: false,
        canAddCash: false,
        canWithdrawCash: false,
        canTransferCash: false,
        canManagePartners: false,
        canManageRoles: false,
        canManageCompany: false,
        canManageAssets: false,
        canApproveRequests: false,
        canBackup: false,
        canEditOwnCashOnly: false,
        canViewOwnDataOnly: true,
        canManageNotes: false,
        canManageProofs: false,
        canManageTestimonials: false,
      },
    ]);
    console.log("Permission roles seeded");
  }

  // Seed sample partners
  const existingPartners = await db.select().from(partners);
  if (existingPartners.length === 0) {
    await db.insert(partners).values([
      {
        displayName: "Volkov",
        discordUsername: "volkov",
        discordId: "123456789",
        companyRoleId: 1,
        permissionRoleId: 1,
        totalCapital: "2000000",
        totalCash: "500000",
        isActive: true,
      },
      {
        displayName: "Donnie",
        discordUsername: "_.400",
        discordId: "987654321",
        companyRoleId: 3,
        permissionRoleId: 1,
        totalCapital: "1000000",
        totalCash: "1500000",
        isActive: true,
      },
      {
        displayName: "Alex",
        discordUsername: "alex_01",
        discordId: "456789123",
        companyRoleId: 4,
        permissionRoleId: 3,
        totalCapital: "500000",
        totalCash: "300000",
        isActive: true,
      },
    ]);
    console.log("Sample partners seeded");
  }

  // Seed sample notes
  const existingNotes = await db.select().from(notes);
  if (existingNotes.length === 0) {
    await db.insert(notes).values([
      {
        title: "Welcome to Volkov Company ERP",
        content: "This is the central management system for all company operations. Use the sidebar to navigate between different sections.",
        isPinned: true,
        priority: "high",
      },
      {
        title: "Monthly Review",
        content: "Schedule monthly financial review meeting with all partners to discuss capital and cash positions.",
        isPinned: false,
        priority: "medium",
      },
    ]);
    console.log("Sample notes seeded");
  }

  // Seed sample testimonials
  const existingTestimonials = await db.select().from(testimonials);
  if (existingTestimonials.length === 0) {
    await db.insert(testimonials).values([
      {
        name: "Sarah",
        discordUsername: "sarah_k",
        content: "Great company with amazing management system!",
        rating: 5,
      },
      {
        name: "Mike",
        discordUsername: "mike_t",
        content: "Professional and well-organized operations.",
        rating: 5,
      },
    ]);
    console.log("Sample testimonials seeded");
  }

  // Seed discord settings
  const existingDiscord = await db.select().from(discordSettings);
  if (existingDiscord.length === 0) {
    await db.insert(discordSettings).values({
      webhookUrl: "",
      isEnabled: false,
      logChannelName: "volkov-logs",
    });
    console.log("Discord settings seeded");
  }

  console.log("Seeding complete!");
}

seed().catch(console.error);
