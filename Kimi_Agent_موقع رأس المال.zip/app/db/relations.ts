import { relations } from "drizzle-orm";
import {
  users,
  partners,
  companyRoles,
  permissionRoles,
  capitalTransactions,
  cashTransactions,
  assets,
  assetTransfers,
} from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  partners: many(partners),
}));

export const companyRolesRelations = relations(companyRoles, ({ many }) => ({
  partners: many(partners),
}));

export const permissionRolesRelations = relations(permissionRoles, ({ many }) => ({
  partners: many(partners),
}));

export const partnersRelations = relations(partners, ({ one, many }) => ({
  companyRole: one(companyRoles, {
    fields: [partners.companyRoleId],
    references: [companyRoles.id],
  }),
  permissionRole: one(permissionRoles, {
    fields: [partners.permissionRoleId],
    references: [permissionRoles.id],
  }),
  capitalTransactions: many(capitalTransactions),
  cashTransactions: many(cashTransactions),
  assets: many(assets),
}));

export const capitalTransactionsRelations = relations(capitalTransactions, ({ one }) => ({
  partner: one(partners, {
    fields: [capitalTransactions.partnerId],
    references: [partners.id],
  }),
}));

export const cashTransactionsRelations = relations(cashTransactions, ({ one }) => ({
  partner: one(partners, {
    fields: [cashTransactions.partnerId],
    references: [partners.id],
  }),
}));

export const assetsRelations = relations(assets, ({ one, many }) => ({
  partner: one(partners, {
    fields: [assets.partnerId],
    references: [partners.id],
  }),
  transfers: many(assetTransfers),
}));

export const assetTransfersRelations = relations(assetTransfers, ({ one }) => ({
  asset: one(assets, {
    fields: [assetTransfers.assetId],
    references: [assets.id],
  }),
}));
