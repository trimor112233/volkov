import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  decimal,
  int,
  boolean,
} from "drizzle-orm/mysql-core";

// ── Users (system auth) ──
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ── Company Info ──
export const companyInfo = mysqlTable("company_info", {
  id: serial("id").primaryKey(),
  companyName: varchar("company_name", { length: 255 }).default("Volkov Company").notNull(),
  description: text("description"),
  logo: text("logo"),
  foundedDate: varchar("founded_date", { length: 50 }),
  location: varchar("location", { length: 255 }),
  discordLink: varchar("discord_link", { length: 500 }),
  primaryColor: varchar("primary_color", { length: 20 }).default("#1a1a2e"),
  secondaryColor: varchar("secondary_color", { length: 20 }).default("#16213e"),
  accentColor: varchar("accent_color", { length: 20 }).default("#e94560"),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
  updatedBy: bigint("updated_by", { mode: "number", unsigned: true }),
});

// ── Company Roles (display roles, not permissions) ──
export const companyRoles = mysqlTable("company_roles", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  displayName: varchar("display_name", { length: 100 }).notNull(),
  rank: int("rank").default(0).notNull(),
  color: varchar("color", { length: 20 }).default("#e94560"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Permission Roles (functional roles) ──
export const permissionRoles = mysqlTable("permission_roles", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull().unique(),
  displayName: varchar("display_name", { length: 50 }).notNull(),
  description: text("description"),
  canViewLogs: boolean("can_view_logs").default(false).notNull(),
  canAddCapital: boolean("can_add_capital").default(false).notNull(),
  canWithdrawCapital: boolean("can_withdraw_capital").default(false).notNull(),
  canAddCash: boolean("can_add_cash").default(false).notNull(),
  canWithdrawCash: boolean("can_withdraw_cash").default(false).notNull(),
  canTransferCash: boolean("can_transfer_cash").default(false).notNull(),
  canManagePartners: boolean("can_manage_partners").default(false).notNull(),
  canManageRoles: boolean("can_manage_roles").default(false).notNull(),
  canManageCompany: boolean("can_manage_company").default(false).notNull(),
  canManageAssets: boolean("can_manage_assets").default(false).notNull(),
  canApproveRequests: boolean("can_approve_requests").default(false).notNull(),
  canBackup: boolean("can_backup").default(false).notNull(),
  canEditOwnCashOnly: boolean("can_edit_own_cash_only").default(false).notNull(),
  canViewOwnDataOnly: boolean("can_view_own_data_only").default(false).notNull(),
  canManageNotes: boolean("can_manage_notes").default(false).notNull(),
  canManageProofs: boolean("can_manage_proofs").default(false).notNull(),
  canManageTestimonials: boolean("can_manage_testimonials").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Partners ──
export const partners = mysqlTable("partners", {
  id: serial("id").primaryKey(),
  displayName: varchar("display_name", { length: 255 }).notNull(),
  discordUsername: varchar("discord_username", { length: 255 }).notNull(),
  discordId: varchar("discord_id", { length: 100 }),
  discordAvatar: text("discord_avatar"),
  discordProfileUrl: text("discord_profile_url"),
  companyRoleId: bigint("company_role_id", { mode: "number", unsigned: true }),
  permissionRoleId: bigint("permission_role_id", { mode: "number", unsigned: true }),
  totalCapital: decimal("total_capital", { precision: 18, scale: 2 }).default("0").notNull(),
  totalCash: decimal("total_cash", { precision: 18, scale: 2 }).default("0").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  isPending: boolean("is_pending").default(false).notNull(),
  activationRequestId: bigint("activation_request_id", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

// ── Capital Transactions ──
export const capitalTransactions = mysqlTable("capital_transactions", {
  id: serial("id").primaryKey(),
  partnerId: bigint("partner_id", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["deposit", "withdrawal"]).notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  note: text("note"),
  receiptImage: text("receipt_image"),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Cash Transactions ──
export const cashTransactions = mysqlTable("cash_transactions", {
  id: serial("id").primaryKey(),
  partnerId: bigint("partner_id", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["deposit", "withdrawal", "transfer"]).notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  note: text("note"),
  receiptImage: text("receipt_image"),
  transferToPartnerId: bigint("transfer_to_partner_id", { mode: "number", unsigned: true }),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Approval Requests ──
export const approvalRequests = mysqlTable("approval_requests", {
  id: serial("id").primaryKey(),
  requesterId: bigint("requester_id", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["cash_withdrawal", "cash_transfer", "capital_withdrawal"]).notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  note: text("note"),
  targetPartnerId: bigint("target_partner_id", { mode: "number", unsigned: true }),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  reviewedBy: bigint("reviewed_by", { mode: "number", unsigned: true }),
  reviewNote: text("review_note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
});

// ── Assets ──
export const assets = mysqlTable("assets", {
  id: serial("id").primaryKey(),
  partnerId: bigint("partner_id", { mode: "number", unsigned: true }).notNull(),
  assetName: varchar("asset_name", { length: 255 }).notNull(),
  assetType: mysqlEnum("asset_type", ["vehicles", "real_estate", "equipment", "other"]).notNull(),
  assetIdCode: varchar("asset_id_code", { length: 255 }).notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

// ── Asset Transfers ──
export const assetTransfers = mysqlTable("asset_transfers", {
  id: serial("id").primaryKey(),
  assetId: bigint("asset_id", { mode: "number", unsigned: true }).notNull(),
  fromPartnerId: bigint("from_partner_id", { mode: "number", unsigned: true }).notNull(),
  toPartnerId: bigint("to_partner_id", { mode: "number", unsigned: true }).notNull(),
  toPartnerName: varchar("to_partner_name", { length: 255 }).notNull(),
  toPartnerDiscordId: varchar("to_partner_discord_id", { length: 100 }),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Logs ──
export const logs = mysqlTable("logs", {
  id: serial("id").primaryKey(),
  type: mysqlEnum("type", [
    "capital_deposit",
    "capital_withdrawal",
    "cash_deposit",
    "cash_withdrawal",
    "cash_transfer",
    "asset_added",
    "asset_transferred",
    "partner_added",
    "partner_updated",
    "role_changed",
    "company_updated",
    "approval_requested",
    "approval_approved",
    "approval_rejected",
    "login",
    "logout",
    "note_added",
    "proof_added",
    "testimonial_added",
  ]).notNull(),
  partnerId: bigint("partner_id", { mode: "number", unsigned: true }),
  targetPartnerId: bigint("target_partner_id", { mode: "number", unsigned: true }),
  amount: decimal("amount", { precision: 18, scale: 2 }),
  description: text("description").notNull(),
  details: text("details"),
  receiptImage: text("receipt_image"),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Testimonials ──
export const testimonials = mysqlTable("testimonials", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  discordUsername: varchar("discord_username", { length: 255 }),
  content: text("content").notNull(),
  rating: int("rating").default(5).notNull(),
  isApproved: boolean("is_approved").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Proofs ──
export const proofs = mysqlTable("proofs", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["sale", "purchase", "transfer", "contract", "other"]).notNull(),
  imageUrl: text("image_url"),
  partnerId: bigint("partner_id", { mode: "number", unsigned: true }),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Notes ──
export const notes = mysqlTable("notes", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  isPinned: boolean("is_pinned").default(false).notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

// ── Activation Requests ──
export const activationRequests = mysqlTable("activation_requests", {
  id: serial("id").primaryKey(),
  displayName: varchar("display_name", { length: 255 }).notNull(),
  discordUsername: varchar("discord_username", { length: 255 }).notNull(),
  discordId: varchar("discord_id", { length: 100 }),
  discordAvatar: text("discord_avatar"),
  discordProfileUrl: text("discord_profile_url"),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  reviewedBy: bigint("reviewed_by", { mode: "number", unsigned: true }),
  reviewNote: text("review_note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
});

// ── Discord Settings ──
export const discordSettings = mysqlTable("discord_settings", {
  id: serial("id").primaryKey(),
  webhookUrl: text("webhook_url"),
  isEnabled: boolean("is_enabled").default(false).notNull(),
  logChannelName: varchar("log_channel_name", { length: 255 }).default("volkov-logs"),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
  updatedBy: bigint("updated_by", { mode: "number", unsigned: true }),
});

// ── Notifications ──
export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  partnerId: bigint("partner_id", { mode: "number", unsigned: true }),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  type: mysqlEnum("type", ["info", "success", "warning", "error"]).default("info").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  relatedEntityType: varchar("related_entity_type", { length: 50 }),
  relatedEntityId: bigint("related_entity_id", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
